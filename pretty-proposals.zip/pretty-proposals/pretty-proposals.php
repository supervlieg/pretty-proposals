<?php
/**
 * Plugin Name:       Pretty Proposals
 * Plugin URI:        https://willemprinsloo.com/pretty-proposals/
 * Description:       Manage client proposals directly within WordPress. Create, customize, PDF, and send proposals with ease.
 * Version:           1.0.8
 * Author:            Willem Prinsloo
 * Author URI:        https://willemprinsloo.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pretty-proposals
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Register the Proposal Custom Post Type.
 */
function ppr_register_proposal_post_type() {

	$labels = array(
		'name'                  => _x( 'Proposals', 'Post Type General Name', 'pretty-proposals' ),
		'singular_name'         => _x( 'Proposal', 'Post Type Singular Name', 'pretty-proposals' ),
		'menu_name'             => __( 'Proposals', 'pretty-proposals' ),
		'name_admin_bar'        => __( 'Proposal', 'pretty-proposals' ),
		'archives'              => __( 'Proposal Archives', 'pretty-proposals' ),
		'attributes'            => __( 'Proposal Attributes', 'pretty-proposals' ),
		'parent_item_colon'     => __( 'Parent Proposal:', 'pretty-proposals' ),
		'all_items'             => __( 'All Proposals', 'pretty-proposals' ),
		'add_new_item'          => __( 'Add New Proposal', 'pretty-proposals' ),
		'add_new'               => __( 'Add New', 'pretty-proposals' ),
		'new_item'              => __( 'New Proposal', 'pretty-proposals' ),
		'edit_item'             => __( 'Edit Proposal', 'pretty-proposals' ),
		'update_item'           => __( 'Update Proposal', 'pretty-proposals' ),
		'view_item'             => __( 'View Proposal', 'pretty-proposals' ),
		'view_items'            => __( 'View Proposals', 'pretty-proposals' ),
		'search_items'          => __( 'Search Proposal', 'pretty-proposals' ),
		'not_found'             => __( 'Not found', 'pretty-proposals' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'pretty-proposals' ),
		'featured_image'        => __( 'Featured Image', 'pretty-proposals' ), // Though we might not use it initially
		'set_featured_image'    => __( 'Set featured image', 'pretty-proposals' ),
		'remove_featured_image' => __( 'Remove featured image', 'pretty-proposals' ),
		'use_featured_image'    => __( 'Use as featured image', 'pretty-proposals' ),
		'insert_into_item'      => __( 'Insert into proposal', 'pretty-proposals' ),
		'uploaded_to_this_item' => __( 'Uploaded to this proposal', 'pretty-proposals' ),
		'items_list'            => __( 'Proposals list', 'pretty-proposals' ),
		'items_list_navigation' => __( 'Proposals list navigation', 'pretty-proposals' ),
		'filter_items_list'     => __( 'Filter proposals list', 'pretty-proposals' ),
	);
	$args = array(
		'label'                 => __( 'Proposal', 'pretty-proposals' ),
		'description'           => __( 'Custom Post Type for Client Proposals', 'pretty-proposals' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'revisions' ), // Title for internal name, Editor for Scope
		'taxonomies'            => array(), // No default taxonomies for now
		'hierarchical'          => false,
		'public'                => true, // Needs to be public for admin UI, but we can hide front-end view
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 20, // Below Pages
		'menu_icon'             => 'dashicons-media-document',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => false, // Not needed for nav menus
		'can_export'            => true,
		'has_archive'           => false, // No public archive page needed
		'exclude_from_search'   => true, // Exclude from front-end site search
		'publicly_queryable'    => true, // << CHANGED FROM false
		'capability_type'       => 'post', // Standard post capabilities
        'show_in_rest'          => true, // Enable Gutenberg editor support / REST API access
	);
	// Changed CPT slug to 'pretty_proposal'
	register_post_type( 'pretty_proposal', $args );

}
add_action( 'init', 'ppr_register_proposal_post_type', 0 );

// --- Rewrite Rules & Query Vars ---

/**
 * Add rewrite rule for public proposal view.
 */
function ppr_add_proposal_rewrite_rule() {
    add_rewrite_rule(
        '^proposal/([0-9]+)/([a-zA-Z0-9]+)/?$', // Matches /proposal/123/key
        'index.php?post_type=pretty_proposal&p=$matches[1]&proposal_key=$matches[2]',
        'top' // Add rule at the top
    );
}
add_action( 'init', 'ppr_add_proposal_rewrite_rule' );

/**
 * Add custom query variable for the proposal key.
 *
 * @param array $vars Existing query variables.
 * @return array Modified query variables.
 */
function ppr_add_query_vars( $vars ) {
    $vars[] = 'proposal_key';
    return $vars;
}
add_filter( 'query_vars', 'ppr_add_query_vars' );

/**
 * Flush rewrite rules on plugin activation.
 */
function ppr_plugin_activation() {
	// First, we register the post type again to be safe.
	ppr_register_proposal_post_type();
	// Then, we flush the rewrite rules.
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ppr_plugin_activation' );

/**
 * Flush rewrite rules on plugin deactivation.
 * Not strictly necessary for CPTs, but good practice sometimes.
 */
function ppr_plugin_deactivation() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'ppr_plugin_deactivation' );

// --- Meta Boxes and Core Logic Will Go Here ---

/**
 * Add meta boxes for proposal details.
 */
function ppr_add_proposal_meta_boxes() {
    add_meta_box(
        'ppr_client_details_meta_box',       // Unique ID
        __( 'Client Details', 'pretty-proposals' ), // Box title
        'ppr_client_details_meta_box_html',  // Content callback, must be of type callable
        'pretty_proposal',                    // Post type (Changed)
        'normal',                             // Context ('normal', 'side', 'advanced')
        'high'                                // Priority
    );
    add_meta_box(
        'ppr_proposal_details_meta_box',     // Unique ID
        __( 'Proposal Details', 'pretty-proposals' ),// Box title
        'ppr_proposal_details_meta_box_html',// Content callback
        'pretty_proposal',                    // Post type (Changed)
        'normal',                             // Context
        'high'                                // Priority
    );
     add_meta_box(
        'ppr_proposal_status_meta_box',      // Unique ID
        __( 'Proposal Status', 'pretty-proposals' ), // Box title
        'ppr_proposal_status_meta_box_html', // Content callback
        'pretty_proposal',                    // Post type (Changed)
        'side',                               // Context -> side
        'high'                                // Priority
    );
    // Add Send Proposal Meta Box
    add_meta_box(
        'ppr_send_proposal_meta_box',       // Unique ID
        __( 'Send Proposal', 'pretty-proposals' ),  // Box title
        'ppr_send_proposal_meta_box_html',   // Content callback
        'pretty_proposal',                    // Post type (Changed)
        'side',                               // Context -> side
        'high'                                // Priority
    );

    // Add Proposal Items Meta Box
    add_meta_box(
        'ppr_proposal_items_meta_box',      // Unique ID
        __( 'Proposal Items & Pricing', 'pretty-proposals' ), // Box title
        'ppr_proposal_items_meta_box_html', // Content callback
        'pretty_proposal',                   // Post type
        'normal',                            // Context
        'high'                               // Priority
    );
}
// Changed hook name
add_action( 'add_meta_boxes_pretty_proposal', 'ppr_add_proposal_meta_boxes' );

/**
 * Callback function to display HTML for the Client Details meta box.
 *
 * @param WP_Post $post The current post object.
 */
function ppr_client_details_meta_box_html( $post ) {
    // Add a nonce field for security
    wp_nonce_field( 'ppr_save_proposal_meta', 'ppr_proposal_nonce' ); // Renamed nonce

    // Retrieve existing values from the database (using new meta keys)
    $client_name = get_post_meta( $post->ID, '_ppr_client_name', true );
    $client_company = get_post_meta( $post->ID, '_ppr_client_company', true );
    $client_email = get_post_meta( $post->ID, '_ppr_client_email', true );
    $client_address = get_post_meta( $post->ID, '_ppr_client_address', true ); // New
    $client_vat = get_post_meta( $post->ID, '_ppr_client_vat', true );       // New

    ?>
    <p>
        <label for="ppr_client_name"><?php _e( 'Client Name', 'pretty-proposals' ); ?>:</label><br>
        <input type="text" id="ppr_client_name" name="ppr_client_name" value="<?php echo esc_attr( $client_name ); ?>" class="widefat" />
    </p>
    <p>
        <label for="ppr_client_company"><?php _e( 'Company', 'pretty-proposals' ); ?>:</label><br>
        <input type="text" id="ppr_client_company" name="ppr_client_company" value="<?php echo esc_attr( $client_company ); ?>" class="widefat" />
    </p>
    <p>
        <label for="ppr_client_email"><?php _e( 'Client Email', 'pretty-proposals' ); ?>:</label><br>
        <input type="email" id="ppr_client_email" name="ppr_client_email" value="<?php echo esc_attr( $client_email ); ?>" class="widefat" />
    </p>
    <p>
        <label for="ppr_client_address"><?php _e( 'Client Address', 'pretty-proposals' ); ?>:</label><br>
        <textarea id="ppr_client_address" name="ppr_client_address" rows="4" class="widefat"><?php echo esc_textarea( $client_address ); ?></textarea>
        <span class="description"><?php _e( 'Enter the client\'s full address, one part per line.', 'pretty-proposals' ); ?></span>
    </p>
     <p>
        <label for="ppr_client_vat"><?php _e( 'Client VAT Number (Optional)', 'pretty-proposals' ); ?>:</label><br>
        <input type="text" id="ppr_client_vat" name="ppr_client_vat" value="<?php echo esc_attr( $client_vat ); ?>" class="regular-text" />
    </p>
    <?php
}

/**
 * Callback function to display HTML for the Proposal Details meta box.
 *
 * @param WP_Post $post The current post object.
 */
function ppr_proposal_details_meta_box_html( $post ) {
    // Nonce field is added in the client details box, no need to repeat

    // Retrieve existing value from the database (using new meta key)
    $proposal_number = get_post_meta( $post->ID, '_ppr_proposal_number', true );

    ?>
    <p>
        <label for="ppr_proposal_number"><?php _e( 'Proposal Number', 'pretty-proposals' ); ?>:</label><br>
        <input type="text" id="ppr_proposal_number" name="ppr_proposal_number" value="<?php echo esc_attr( $proposal_number ); ?>" class="regular-text" />
        <span class="description"><?php _e( 'Unique identifier for this proposal. Auto-generated if left blank on first save.', 'pretty-proposals' ); ?></span>
    </p>
    <p>
        <strong><?php _e( 'Scope of Work:', 'pretty-proposals' ); ?></strong><br>
        <span class="description"><?php _e( 'Use the main editor above to detail the scope of work.', 'pretty-proposals' ); ?></span>
    </p>
    <?php
}

/**
 * Callback function to display HTML for the Proposal Status meta box.
 *
 * @param WP_Post $post The current post object.
 */
function ppr_proposal_status_meta_box_html( $post ) {
    // Nonce field is added in the client details box

    $current_status = get_post_meta( $post->ID, '_ppr_proposal_status', true ); // Renamed meta key
    // Set default status to 'draft' if not set
    if ( empty( $current_status ) ) {
        $current_status = 'draft';
    }

    $statuses = array(
        'draft'    => __( 'Draft', 'pretty-proposals' ),
        'sent'     => __( 'Sent', 'pretty-proposals' ),
        'accepted' => __( 'Accepted', 'pretty-proposals' ),
        'rejected' => __( 'Rejected', 'pretty-proposals' ),
    );

    ?>
    <p>
        <label for="ppr_proposal_status"><?php _e( 'Status', 'pretty-proposals' ); ?>:</label><br>
        <select id="ppr_proposal_status" name="ppr_proposal_status" class="widefat">
            <?php foreach ( $statuses as $value => $label ) : ?>
                <option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_status, $value ); ?>><?php echo esc_html( $label ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <?php
}


/**
 * Callback function to display HTML for the Send Proposal meta box.
 *
 * @param WP_Post $post The current post object.
 */
function ppr_send_proposal_meta_box_html( $post ) {
    // Add a nonce field specifically for the send action
    wp_nonce_field( 'ppr_send_proposal_action', 'ppr_send_proposal_nonce' ); // Renamed nonce

    $client_email = get_post_meta( $post->ID, '_ppr_client_email', true ); // Renamed meta key
    $current_status = get_post_meta( $post->ID, '_ppr_proposal_status', true ) ?: 'draft'; // Default to draft // Renamed meta key
    $proposal_key = get_post_meta( $post->ID, '_ppr_proposal_key', true );

    // Display Shareable Link
    if ( !empty($proposal_key) && $post->post_status === 'publish' ) { // Only show for published posts with a key
         $share_url = home_url( '/proposal/' . $post->ID . '/' . $proposal_key . '/' );
         echo '<p><strong>' . __( 'Shareable Link:', 'pretty-proposals' ) . '</strong></p>';
         echo '<input type="text" value="' . esc_url($share_url) . '" readonly class="widefat" onclick="this.select();" />';
         echo '<p class="description">' . __( 'Client can view and respond to the proposal using this link.', 'pretty-proposals' ) . '</p>';
         echo '<hr>';
    } elseif ($post->post_status !== 'publish') {
         echo '<p><em>' . __( 'Publish the proposal to generate the shareable link.', 'pretty-proposals' ) . '</em></p>';
    }

    echo '<div id="ppr-send-status"></div>'; // Area for AJAX messages - Renamed ID

    if ( empty( $client_email ) ) {
        echo '<p>' . esc_html__( 'Please enter and save a client email address before sending.', 'pretty-proposals' ) . '</p>';
        return; // Don't show button if no email
    }

    // Optionally, disable if already sent, accepted, or rejected?
    // For now, we allow resending.

    echo '<button type="button" id="ppr-send-proposal-button" class="button button-primary" data-postid="' . esc_attr( $post->ID ) . '">'; // Renamed ID
    echo esc_html__( 'Send Proposal to Client', 'pretty-proposals' );
    echo '</button>'; // << ADDED MISSING CLOSING TAG
    echo '<span class="spinner" style="float: none; vertical-align: middle; margin-left: 5px;"></span>'; // Spinner for visual feedback

    // --- Add Download Invoice Button ---
    if ( $current_status === 'accepted' ) {
        echo '<hr style="margin-top: 15px; margin-bottom: 15px;">';

        $download_nonce = wp_create_nonce( 'ppr_download_invoice_' . $post->ID );
        $download_url = admin_url( 'admin-post.php?action=ppr_download_invoice&proposal_id=' . $post->ID . '&_wpnonce=' . $download_nonce );

        echo '<a href="' . esc_url( $download_url ) . '" id="ppr-download-invoice-button" class="button button-secondary" target="_blank">'; // Use target="_blank" for smoother download start
        echo esc_html__( 'Download Invoice PDF', 'pretty-proposals' );
        echo '</a>';
         echo '<p class="description">' . __( 'Generate and download the invoice for this accepted proposal.', 'pretty-proposals' ) . '</p>';
    }

}

/**
 * Save meta box content.
 *
 * @param int $post_id Post ID
 */
function ppr_save_proposal_meta( $post_id ) {
    // Check if our nonce is set.
    if ( ! isset( $_POST['ppr_proposal_nonce'] ) ) { // Renamed nonce
        return;
    }

    // Verify that the nonce is valid.
    if ( ! wp_verify_nonce( $_POST['ppr_proposal_nonce'], 'ppr_save_proposal_meta' ) ) { // Renamed nonce action
        return;
    }

    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    // Check the user's permissions.
    if ( isset( $_POST['post_type'] ) && 'pretty_proposal' == $_POST['post_type'] ) { // Changed CPT slug
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
    } else {
         // Assuming this is for posts or pages, requires edit_page capability.
        // Adjust capability check if needed for other post types.
        if ( ! current_user_can( 'edit_page', $post_id ) ) {
             return;
        }
    }

    /* OK, it's safe for us to save the data now. */

    // Sanitize user input and update the meta fields.
    $fields_to_save = [
        'ppr_client_name'    => '_ppr_client_name',
        'ppr_client_company' => '_ppr_client_company',
        'ppr_client_email'   => '_ppr_client_email',
        'ppr_client_address' => '_ppr_client_address', // New
        'ppr_client_vat'     => '_ppr_client_vat',     // New
        'ppr_proposal_status' => '_ppr_proposal_status',
        'ppr_proposal_number' => '_ppr_proposal_number', 
    ];

    $sanitize_callbacks = [
         'ppr_client_name'    => 'sanitize_text_field',
         'ppr_client_company' => 'sanitize_text_field',
         'ppr_client_email'   => 'sanitize_email',
         'ppr_client_address' => 'sanitize_textarea_field', // New
         'ppr_client_vat'     => 'sanitize_text_field',     // New
         'ppr_proposal_status' => 'sanitize_key',       
         'ppr_proposal_number' => 'sanitize_text_field', 
    ];

    foreach ( $fields_to_save as $field_name => $meta_key ) {
        if ( isset( $_POST[ $field_name ] ) ) {
             $sanitize_callback = isset($sanitize_callbacks[$field_name]) ? $sanitize_callbacks[$field_name] : 'sanitize_text_field';
             $value = call_user_func( $sanitize_callback, $_POST[ $field_name ] );

             // Auto-generate proposal number if empty on first save
             if ( $field_name === 'ppr_proposal_number' && empty( $value ) ) {
                 // Check if it already exists - only generate if it doesn't
                 $existing_number = get_post_meta( $post_id, $meta_key, true );
                 if ( empty( $existing_number ) ) {
                     $value = 'PROP-' . $post_id;
                 }
                 // If it exists, keep the submitted empty value (or the existing one? Let's keep existing)
                 elseif (!empty($existing_number)) {
                      $value = $existing_number; // Don't overwrite existing with blank
                 }
             }

             update_post_meta( $post_id, $meta_key, $value );
        } else {
            // If a field is not submitted and it's the proposal number, ensure it gets generated if needed
            if ($field_name === 'ppr_proposal_number') {
                 $existing_number = get_post_meta( $post_id, $meta_key, true );
                 if ( empty( $existing_number ) ) {
                     $generated_value = 'PROP-' . $post_id;
                     update_post_meta( $post_id, $meta_key, $generated_value );
                 }
            } else if ($meta_key === '_ppr_client_vat') {
                 // Explicitly delete VAT if not submitted, as it's optional
                 delete_post_meta( $post_id, $meta_key );
            }
        }
    }

    // --- Save Line Items ---
    if ( isset( $_POST['ppr_items'] ) && is_array( $_POST['ppr_items'] ) ) {
        $sanitized_items = array();
        foreach ( $_POST['ppr_items'] as $item ) {
            if ( isset( $item['description'] ) || isset( $item['price'] ) ) {
                $description = isset( $item['description'] ) ? sanitize_text_field( $item['description'] ) : '';
                // Sanitize price as float, ensuring non-negative
                $price = isset( $item['price'] ) ? max(0, floatval( $item['price'] )) : 0;

                // Only add item if description or price is not empty (or price > 0)
                if ( ! empty( $description ) || $price > 0 ) {
                    $sanitized_items[] = array(
                        'description' => $description,
                        'price' => $price,
                    );
                }
            }
        }
        // Save the array of sanitized items
        update_post_meta( $post_id, '_ppr_proposal_items', $sanitized_items );
    } else {
        // If no items submitted, perhaps delete the meta? Or save an empty array?
        // Saving empty array is safer if relying on it existing.
         update_post_meta( $post_id, '_ppr_proposal_items', array() );
    }

    // --- Generate Unique Key if not present ---
    $proposal_key = get_post_meta( $post_id, '_ppr_proposal_key', true );
    if ( empty( $proposal_key ) ) {
        // Generate a unique key (e.g., random string)
        $proposal_key = wp_generate_password( 20, false ); // 20 chars, no special chars
        update_post_meta( $post_id, '_ppr_proposal_key', $proposal_key );
    }

}
// Changed hook name
add_action( 'save_post_pretty_proposal', 'ppr_save_proposal_meta' );

// --- PDF Generation ---

// Extend FPDF to add Footer with Page Numbers
if ( file_exists( plugin_dir_path( __FILE__ ) . 'lib/fpdf.php' ) ) {
    require_once( plugin_dir_path( __FILE__ ) . 'lib/fpdf.php' );

    // Renamed class
    class PPR_PDF extends FPDF {
        // Page footer
        function Footer() {
            // Position at 1.5 cm from bottom
            $this->SetY(-15);
            // Set font
            // *** FIXED SYNTAX ERROR HERE ***
            $this->SetFont('Arial', 'I', 8);
            // Page number centered
            $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
        }
    }
} else {
     // Optional: Add an admin notice if FPDF is missing, maybe?
     // For now, the generate function handles the error.
}


/**
 * Generate a PDF file for a given proposal.
 *
 * @param int $post_id The ID of the proposal post.
 * @return string|WP_Error Path to the generated PDF file or WP_Error on failure.
 */
function ppr_generate_proposal_pdf( $post_id ) {

    // Ensure FPDF library and our extension class exists
    $fpdf_path = plugin_dir_path( __FILE__ ) . 'lib/fpdf.php';
    // Check for renamed class
    if ( ! file_exists( $fpdf_path ) || ! class_exists('PPR_PDF') ) {
        return new WP_Error( 'fpdf_class_not_found', __( 'FPDF library or PPR_PDF extension class not found. Ensure fpdf.php is placed in the plugin\'s lib directory.', 'pretty-proposals' ) );
    }
    // FPDF is already required once above where PPR_PDF is defined

    // Get proposal data
    $post = get_post( $post_id );
    if ( ! $post || $post->post_type !== 'pretty_proposal' ) { // Check for new CPT slug
        return new WP_Error( 'invalid_post', __( 'Invalid proposal ID provided.', 'pretty-proposals' ) );
    }

    // Get meta data (using new meta keys)
    $client_name    = get_post_meta( $post_id, '_ppr_client_name', true );
    $client_company = get_post_meta( $post_id, '_ppr_client_company', true );
    $client_email   = get_post_meta( $post_id, '_ppr_client_email', true );
    $scope_of_work  = $post->post_content; // Get content from the main editor
    $proposal_title = $post->post_title; // Use the post title

    // --- Get Settings ---
    $options = get_option( 'ppr_settings' );
    $raw_currency_symbol = isset( $options['currency_symbol'] ) ? $options['currency_symbol'] : '$';
    $currency_symbol = html_entity_decode( $raw_currency_symbol, ENT_QUOTES, 'UTF-8' ); // Decode for PDF

    // --- Start PDF Creation ---
    // Use our custom class instead of the base FPDF class (Renamed)
    $pdf = new PPR_PDF();
    $pdf->AliasNbPages(); // Enable total page number alias {nb}
    $pdf->AddPage();
    $pdf->SetMargins(20, 20, 20);


    // --- Define Layout Variables ---
    $page_width = $pdf->GetPageWidth();
    $left_margin = 20;
    $right_margin = 20;
    $content_width = $page_width - $left_margin - $right_margin;
    $half_width = $content_width / 2;
    $current_y = 15; // Initial Y position

    // --- Add Company Logo (if set) ---
    $logo_id = isset( $options['company_logo_id'] ) ? absint( $options['company_logo_id'] ) : 0;
    $logo_path = '';
    if ( $logo_id ) {
        $logo_path = get_attached_file( $logo_id ); // Get the server path
    }

    if ( $logo_path && file_exists( $logo_path ) ) {
        // Basic check for supported image types (FPDF supports JPG, PNG, GIF)
        $image_info = @getimagesize( $logo_path ); // Use @ to suppress potential warnings
        $mime_type = isset( $image_info['mime'] ) ? $image_info['mime'] : '';
        $allowed_mime_types = ['image/jpeg', 'image/png', 'image/gif'];

        if ( $image_info && in_array( $mime_type, $allowed_mime_types ) ) {
            // Calculate position and size
            $max_logo_width_mm = 60; 
            $max_logo_height_mm = 30;
            $ratio = $image_info[0] / $image_info[1];
            $logo_width_mm = $max_logo_width_mm;
            $logo_height_mm = $logo_width_mm / $ratio;
            if ($logo_height_mm > $max_logo_height_mm) {
                $logo_height_mm = $max_logo_height_mm;
                $logo_width_mm = $logo_height_mm * $ratio;
            }
            $logo_x_position = ($page_width - $logo_width_mm) / 2; // Center horizontally

            try {
                 $pdf->Image( $logo_path, $logo_x_position, $current_y, $logo_width_mm, $logo_height_mm );
                 $current_y += $logo_height_mm + 10; // Update Y position below logo + padding
            } catch (Exception $e) {
                 error_log("Pretty Proposals FPDF Image Error: " . $e->getMessage());
                 $current_y += 5; // Add some space even if logo fails
            }
        }
    } else {
         $current_y += 5; // Add some space if no logo
    }

    // --- Header Section (Company Details, Proposal No/Date) ---
    $header_y_start = $current_y;
    $left_col_x = $left_margin;
    $right_col_x = $left_margin + $half_width + 5; // Start right col slightly offset
    $col_width = $half_width - 5; // Adjust width slightly for gap

    // Store Y before MultiCell
    $y_before_company_details = $header_y_start;
    $pdf->SetY($y_before_company_details);
    $pdf->SetX($left_col_x);

    // Left Side: Company Details
    $pdf->SetFont( 'Arial', '', 9 );
    $company_name = isset($options['company_name']) ? $options['company_name'] : '';
    $company_address = isset($options['company_address']) ? $options['company_address'] : '';
    $company_phone = isset($options['company_phone']) ? $options['company_phone'] : '';
    $company_email = isset($options['company_email']) ? $options['company_email'] : '';

    if ($company_name) {
         $pdf->SetFont( 'Arial', 'B', 10 );
         $pdf->Cell( $col_width, 5, $company_name, 0, 1, 'L' );
         $pdf->SetFont( 'Arial', '', 9 );
         $pdf->SetX($left_col_x); // Reset X
    }
    if ($company_address) {
        $pdf->MultiCell( $col_width, 5, $company_address, 0, 'L' );
        $pdf->SetX($left_col_x); // Reset X after MultiCell
    }
    if ($company_phone) {
        $pdf->Cell( $col_width, 5, 'Phone: ' . $company_phone, 0, 1, 'L' );
        $pdf->SetX($left_col_x);
    }
    if ($company_email) {
        $pdf->Cell( $col_width, 5, 'Email: ' . $company_email, 0, 1, 'L' );
    }
    $left_col_end_y = $pdf->GetY();

    // Right Side: Proposal Number & Date
    $pdf->SetY( $header_y_start ); // Reset Y to align top with company details
    $pdf->SetX( $right_col_x );
    $proposal_number = get_post_meta( $post_id, '_ppr_proposal_number', true );
    $proposal_date = date( get_option('date_format', 'F j, Y'), strtotime($post->post_date) ); // Format date

    $pdf->SetFont( 'Arial', 'B', 10 );
    $pdf->Cell( $col_width, 6, 'PROPOSAL', 0, 1, 'R' );
    $pdf->SetX( $right_col_x ); // Reset X
    $pdf->SetFont( 'Arial', '', 9 );
    if ( $proposal_number ) {
        $pdf->Cell( $col_width, 5, 'Proposal #: ' . $proposal_number, 0, 1, 'R' );
        $pdf->SetX( $right_col_x ); // Reset X
    }
    $pdf->Cell( $col_width, 5, 'Date: ' . $proposal_date, 0, 1, 'R' );
    $right_col_end_y = $pdf->GetY();

    // Determine Y position after header block
    $current_y = max($left_col_end_y, $right_col_end_y) + 15; // Use max Y + padding

    // --- Main Title ---
    $pdf->SetY($current_y);
    $pdf->SetFont( 'Arial', 'B', 16 );
    $pdf->Cell( 0, 10, 'Proposal: ' . $proposal_title, 0, 1, 'C' );
    $current_y = $pdf->GetY() + 10; // Update Y + padding

    // Client Information Section
    $pdf->SetY($current_y);
    $pdf->SetFont( 'Arial', 'B', 12 );
    $pdf->SetFillColor(245, 245, 245); // Light gray background
    $pdf->Cell( 0, 8, 'Client Information', 0, 1, 'L', true ); // Add fill
    $pdf->Ln(3);
    $pdf->SetFont( 'Arial', '', 11 );
    if ( $client_name ) {
        $pdf->Cell( 0, 6, 'Name: ' . $client_name, 0, 1 );
    }
    if ( $client_company ) {
        $pdf->Cell( 0, 6, 'Company: ' . $client_company, 0, 1 );
    }
    if ( $client_email ) {
        $pdf->Cell( 0, 6, 'Email: ' . $client_email, 0, 1 );
    }
    $pdf->Ln(10);

    // Scope of Work Section
    $pdf->SetFont( 'Arial', 'B', 12 );
    $pdf->Cell( 0, 7, 'Scope of Work', 0, 1 );
    $pdf->Ln(2); // Small space before content
    $pdf->SetFont( 'Arial', '', 11 );
    // Basic handling for content - FPDF doesn't handle HTML well.
    // We strip tags and decode HTML entities for cleaner text.
    $scope_text = wp_strip_all_tags( html_entity_decode( $scope_of_work ) );
    $scope_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($scope_text, 'ISO-8859-1', 'UTF-8') : $scope_text; // Use mb_convert_encoding
    $pdf->MultiCell( 0, 6, $scope_text_iso ); // Use MultiCell for longer text
    $pdf->Ln(10); // Space after scope

    // --- Line Items Table ---
    $line_items = get_post_meta( $post_id, '_ppr_proposal_items', true );
    if ( ! empty( $line_items ) && is_array( $line_items ) ) {
        $pdf->SetFont( 'Arial', 'B', 12 );
        $pdf->Cell( 0, 7, 'Project Breakdown & Price', 0, 1 );
        $pdf->Ln(3);

        // Table Header
        $pdf->SetFont('Arial','B',10);
        $pdf->SetFillColor(230, 230, 230);
        $pdf->Cell($content_width * 0.8, 7, 'Description', 1, 0, 'L', true);
        $pdf->Cell($content_width * 0.2, 7, 'Price', 1, 1, 'R', true); // Adjust column width

        // Table Body
        $pdf->SetFont('Arial','',10);
        $total_price = 0;
        foreach ( $line_items as $item ) {
            $item_description = isset($item['description']) ? $item['description'] : '';
            $item_price = isset($item['price']) ? floatval($item['price']) : 0;
            $total_price += $item_price;

            // Handle multi-line descriptions - calculate height first?
            // Simple approach for now:
            $item_description_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($item_description, 'ISO-8859-1', 'UTF-8') : $item_description; // Use mb_convert_encoding
            $pdf->Cell($content_width * 0.8, 7, $item_description_iso, 1, 0, 'L');
            $price_text = $currency_symbol . number_format($item_price, 2);
            $price_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($price_text, 'ISO-8859-1', 'UTF-8') : $price_text; // Use mb_convert_encoding
            $pdf->Cell($content_width * 0.2, 7, $price_text_iso, 1, 1, 'R'); 
        }

        // Table Footer (Total)
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell($content_width * 0.8, 7, 'Total', 1, 0, 'R');
        $total_price_text = $currency_symbol . number_format($total_price, 2);
        $total_price_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($total_price_text, 'ISO-8859-1', 'UTF-8') : $total_price_text; // Use mb_convert_encoding
        $pdf->Cell($content_width * 0.2, 7, $total_price_text_iso, 1, 1, 'R'); 
        $pdf->Ln(15); // Space after table
    } else {
         // Optional: Add a message if no line items are found?
         // $pdf->Cell(0, 7, 'Pricing details not available.', 0, 1);
         // $pdf->Ln(10);
    }

    // Footer/Signature Area (Placeholder) - Footer is now handled by PPR_PDF class
    $pdf->SetY(-30); // Position cursor slightly above the footer area for the final text
    $pdf->SetFont( 'Arial', 'I', 10 );
    $pdf->Cell( 0, 10, 'Thank you for considering our proposal.', 0, 1, 'C' );

    // --- Add Link to Online Version ---
    $proposal_key = get_post_meta( $post_id, '_ppr_proposal_key', true );
    if ( $proposal_key && $post->post_status === 'publish' ) {
        $share_url = home_url( '/proposal/' . $post_id . '/' . $proposal_key . '/' );
        $pdf->Ln(5); // Add some space
        $pdf->SetFont( 'Arial', '', 10 );
        $pdf->SetTextColor(0, 0, 200); // Blue color for link
        $pdf->Cell( 0, 6, 'Click here to view and respond to this proposal online', 0, 1, 'C', false, $share_url );
        $pdf->SetTextColor(0, 0, 0); // Reset text color
    }

    // --- Save PDF File ---

    // Create a unique filename
    $upload_dir = wp_upload_dir();
    // Use renamed folder
    $pdf_dir = $upload_dir['basedir'] . '/pretty-proposals';

    // Create the directory if it doesn't exist
    if ( ! file_exists( $pdf_dir ) ) {
        wp_mkdir_p( $pdf_dir );
    }

    // Sanitize title for filename
    $safe_title = sanitize_title( $proposal_title );
    $filename = 'proposal-' . $post_id . '-' . $safe_title . '-' . time() . '.pdf';
    $filepath = $pdf_dir . '/' . $filename;

    try {
        $pdf->Output( 'F', $filepath ); // 'F' saves to a local file
    } catch ( Exception $e ) {
        return new WP_Error( 'pdf_save_error', __( 'Could not save the PDF file: ', 'pretty-proposals' ) . $e->getMessage() );
    }

    // Check if file was created
    if ( ! file_exists( $filepath ) ) {
         return new WP_Error( 'pdf_creation_failed', __( 'Failed to create the PDF file at the specified path.', 'pretty-proposals' ) );
    }

    return $filepath; // Return the full path to the generated file
}

/**
 * Generate an Invoice PDF file for a given proposal.
 *
 * @param int $post_id The ID of the proposal post.
 * @param string $output_mode 'F' to save to file (default), 'D' to force download.
 * @return string|WP_Error|bool Path to the generated PDF file (mode 'F'), true on success (mode 'D'), or WP_Error/false on failure.
 */
function ppr_generate_invoice_pdf( $post_id, $output_mode = 'F' ) { 

    // --- Ensure FPDF library and our extension class exists --- 
    $fpdf_path = plugin_dir_path( __FILE__ ) . 'lib/fpdf.php';
    if ( ! file_exists( $fpdf_path ) ) {
         return new WP_Error( 'fpdf_not_found', __( 'FPDF library (fpdf.php) not found in plugin\'s lib directory.', 'pretty-proposals' ) );
    }
    require_once $fpdf_path; // Ensure FPDF is loaded
    if ( ! class_exists( 'PPR_PDF' ) ) {
        return new WP_Error( 'ppr_pdf_class_definition_not_found', __( 'PPR_PDF class definition is missing or FPDF failed to load.', 'pretty-proposals' ) );
    }

    // --- Get Proposal Data --- 
    $post = get_post( $post_id );
    if ( ! $post || $post->post_type !== 'pretty_proposal' ) {
        return new WP_Error( 'invalid_post', __( 'Invalid proposal ID provided for invoice.', 'pretty-proposals' ) );
    }

    // --- Fetch Meta Data and Settings --- << RESTORED THIS BLOCK
    $invoice_number = get_post_meta( $post_id, '_ppr_invoice_number', true );
    if ( ! $invoice_number ) { // Generate if missing
        $invoice_number = ppr_generate_unique_invoice_number( $post_id );
        update_post_meta( $post_id, '_ppr_invoice_number', $invoice_number );
    }
    $pdf_filename = sanitize_file_name( 'invoice-' . $invoice_number . '.pdf' );

    $client_name    = get_post_meta( $post_id, '_ppr_client_name', true );
    $client_company = get_post_meta( $post_id, '_ppr_client_company', true );
    $proposal_title = $post->post_title; // Still needed for context, even if not directly on invoice

    // Get Settings from options
    $options = get_option( 'ppr_settings' );
    $company_name = isset($options['company_name']) ? $options['company_name'] : '';
    $company_address = isset($options['company_address']) ? $options['company_address'] : '';
    $company_phone = isset($options['company_phone']) ? $options['company_phone'] : '';
    $company_email = isset($options['company_email']) ? $options['company_email'] : '';
    $logo_id = isset( $options['company_logo_id'] ) ? absint( $options['company_logo_id'] ) : 0;
    $payment_terms = isset($options['payment_terms']) ? $options['payment_terms'] : '';
    $banking_details = isset($options['banking_details']) ? $options['banking_details'] : '';
    $raw_currency_symbol = isset( $options['currency_symbol'] ) ? $options['currency_symbol'] : '$';
    $currency_symbol = html_entity_decode( $raw_currency_symbol, ENT_QUOTES, 'UTF-8' );


    // --- PDF Setup --- 
    $pdf = new PPR_PDF('P', 'mm', 'A4'); 
    // ... rest of the function remains the same ...

    // --- PDF Setup ---
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetMargins(20, 20, 20); // Left, Top, Right margins
    $page_width = $pdf->GetPageWidth();
    $content_width = $page_width - 40; // Usable width within margins
    $current_y = 20; // Start Y position slightly lower

    // --- Logo ---
    $logo_id = isset( $options['company_logo_id'] ) ? absint( $options['company_logo_id'] ) : 0;
    $logo_path = '';
    if ( $logo_id ) {
        $logo_path = get_attached_file( $logo_id );
    }
    if ( $logo_path && file_exists( $logo_path ) ) {
         $image_info = @getimagesize( $logo_path );
         $mime_type = isset( $image_info['mime'] ) ? $image_info['mime'] : '';
         $allowed_mime_types = ['image/jpeg', 'image/png', 'image/gif'];
         if ( $image_info && in_array( $mime_type, $allowed_mime_types ) ) {
            $max_logo_width_mm = 60; $max_logo_height_mm = 30;
            list($width, $height) = $image_info;
            if ($width > 0 && $height > 0) { // Prevent division by zero
                $ratio = $width / $height;
                $logo_width_mm = $max_logo_width_mm; $logo_height_mm = $logo_width_mm / $ratio;
                if ($logo_height_mm > $max_logo_height_mm) {$logo_height_mm = $max_logo_height_mm; $logo_width_mm = $logo_height_mm * $ratio;}
                $logo_x_position = ($page_width - $logo_width_mm) / 2; // Center the logo
                try {
                    $image_type = '';
                    switch ($mime_type) {
                        case 'image/jpeg': $image_type = 'JPEG'; break;
                        case 'image/png':  $image_type = 'PNG'; break;
                        case 'image/gif':  $image_type = 'GIF'; break;
                    }
                    if ($image_type) {
                        $pdf->Image( $logo_path, $logo_x_position, $current_y, $logo_width_mm, $logo_height_mm, $image_type );
                        $current_y += $logo_height_mm + 10; // More space after logo
                    } else { $current_y += 5; } 
                } catch (Exception $e) { $current_y += 5; error_log('FPDF Image Error: ' . $e->getMessage()); } 
            } else { $current_y += 5; } // Invalid image dimensions
        }
         else { $current_y += 5; } 
    } else { $current_y += 5; } 

    // --- Header (Invoice Title, Number, Date) ---
    $pdf->SetY($current_y);
    $pdf->SetFont('Arial','B', 24); // Larger, bolder Invoice title
    $pdf->SetTextColor(30, 30, 30); // Dark grey color
    $pdf->Cell(0, 15, 'INVOICE', 0, 1, 'C');
    $pdf->SetTextColor(0, 0, 0); // Reset text color
    $current_y = $pdf->GetY() + 10; // More space after title

    $pdf->SetY($current_y);
    $pdf->SetFont('Arial','B',10); 
    $invoice_date = date( get_option('date_format', 'F j, Y') ); 
    $pdf->Cell($content_width / 2, 5, 'Invoice #: ' . $invoice_number, 0, 0, 'L');
    $pdf->SetFont('Arial','B',10); // Keep date bold as well
    $pdf->Cell($content_width / 2, 5, 'Date: ' . $invoice_date, 0, 1, 'R');
    // --- Calculate and Add Due Date ---
    $due_days = isset($options['invoice_due_days']) ? absint($options['invoice_due_days']) : 30; // Get from settings
    $invoice_timestamp = current_time('timestamp'); // Use WP current time for accuracy
    $due_timestamp = strtotime("+" . $due_days . " days", $invoice_timestamp);
    $due_date = date( get_option('date_format', 'F j, Y'), $due_timestamp );
    $pdf->SetX(20 + $content_width / 2); // Position under Date
    $pdf->SetFont('Arial','B',10);
    $pdf->Cell($content_width / 2, 5, 'Due Date: ' . $due_date, 0, 1, 'R');
    // ---
    $current_y = $pdf->GetY() + 10; // Adjust spacing slightly

    // --- Addresses (Bill To / From) ---
    $pdf->SetY($current_y);
    $col_width = $content_width / 2 - 10; // Slightly narrower cols for more gap
    
    // Draw Headings First
    $pdf->SetFont('Arial','B',11); 
    $pdf->SetTextColor(80, 80, 80); // Medium grey for headings
    $pdf->Cell($col_width, 7, 'FROM:', 0, 0, 'L');
    $pdf->SetX(20 + $col_width + 20); // Position second column heading with wider gap
    $pdf->Cell($col_width, 7, 'BILL TO:', 0, 1, 'L');
    $pdf->SetTextColor(0, 0, 0); // Reset color
    $pdf->Ln(3); // Space below headings
    
    $pdf->SetFont('Arial','',10); 
    $y_after_headings = $pdf->GetY();
    $left_col_y = $y_after_headings;
    $right_col_y = $y_after_headings;
    $cell_padding = 5; // Line height for addresses

    // From Details
    $pdf->SetXY(20, $left_col_y);
    $current_left_y = $left_col_y;
    if ($company_name) { $pdf->SetFont('Arial','B',10); $company_name_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($company_name, 'ISO-8859-1', 'UTF-8') : $company_name; $pdf->Cell($col_width, $cell_padding, $company_name_iso, 0, 1, 'L'); $pdf->SetFont('Arial','',10); $pdf->SetX(20); $current_left_y = $pdf->GetY(); } else { $current_left_y += $cell_padding; }
    if ($company_address) { $company_address_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($company_address, 'ISO-8859-1', 'UTF-8') : $company_address; $pdf->SetX(20); $pdf->MultiCell($col_width, $cell_padding, $company_address_iso, 0, 'L'); $current_left_y = $pdf->GetY(); } else { $current_left_y += $cell_padding; }
    if ($company_phone) { $company_phone_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($company_phone, 'ISO-8859-1', 'UTF-8') : $company_phone; $pdf->SetXY(20, $current_left_y); $pdf->Cell($col_width, $cell_padding, $company_phone_iso, 0, 1, 'L'); $current_left_y = $pdf->GetY(); } else { $current_left_y += $cell_padding; }
    if ($company_email) { $company_email_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($company_email, 'ISO-8859-1', 'UTF-8') : $company_email; $pdf->SetXY(20, $current_left_y); $pdf->Cell($col_width, $cell_padding, $company_email_iso, 0, 1, 'L'); } 
    $left_col_end_y = $pdf->GetY();

    // To Details
    $pdf->SetXY(20 + $col_width + 20, $right_col_y);
    $current_right_y = $right_col_y;
    $client_address = get_post_meta( $post_id, '_ppr_client_address', true ); // Fetch client address
    $client_vat = get_post_meta( $post_id, '_ppr_client_vat', true ); // Fetch client VAT

    if ($client_name) { $pdf->SetFont('Arial','B',10); $client_name_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($client_name, 'ISO-8859-1', 'UTF-8') : $client_name; $pdf->Cell($col_width, $cell_padding, $client_name_iso, 0, 1, 'L'); $pdf->SetFont('Arial','',10); $pdf->SetX(20 + $col_width + 20); $current_right_y = $pdf->GetY(); } else { $current_right_y += $cell_padding; }
    if ($client_company) { $client_company_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($client_company, 'ISO-8859-1', 'UTF-8') : $client_company; $pdf->SetXY(20 + $col_width + 20, $current_right_y); $pdf->Cell($col_width, $cell_padding, $client_company_iso, 0, 1, 'L'); $current_right_y = $pdf->GetY(); } else { $current_right_y += $cell_padding; }
    // Add Client Address
    if ($client_address) { $client_address_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($client_address, 'ISO-8859-1', 'UTF-8') : $client_address; $pdf->SetXY(20 + $col_width + 20, $current_right_y); $pdf->MultiCell($col_width, $cell_padding, $client_address_iso, 0, 'L'); $current_right_y = $pdf->GetY(); } else { $current_right_y += $cell_padding; }
    // Add Client VAT Number (if exists)
    if ($client_vat) { $client_vat_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding('VAT: ' . $client_vat, 'ISO-8859-1', 'UTF-8') : ('VAT: ' . $client_vat); $pdf->SetXY(20 + $col_width + 20, $current_right_y); $pdf->Cell($col_width, $cell_padding, $client_vat_iso, 0, 1, 'L'); }
    $right_col_end_y = $pdf->GetY();
    
    $current_y = max($left_col_end_y, $right_col_end_y) + 18; // More space before table


    // --- Line Items Table Header ---
    $pdf->SetY($current_y);
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFillColor(220, 220, 220); 
    $pdf->SetTextColor(40, 40, 40); 
    $pdf->SetDrawColor(180, 180, 180); 
    $pdf->SetLineWidth(0.3);
    $header_height = 9; 
    // Use full border (1) for header cells
    $pdf->Cell($content_width * 0.6, $header_height, 'Description', 1, 0, 'L', true);
    $pdf->Cell($content_width * 0.1, $header_height, 'Qty', 1, 0, 'C', true);
    $pdf->Cell($content_width * 0.15, $header_height, 'Unit Price', 1, 0, 'R', true);
    $pdf->Cell($content_width * 0.15, $header_height, 'Total', 1, 1, 'R', true);
    $pdf->SetTextColor(0, 0, 0); 
    $pdf->SetLineWidth(0.2); 
    $pdf->SetDrawColor(200, 200, 200); 
    $current_y = $pdf->GetY();

    // --- Line Items Table Rows ---
    $line_items = get_post_meta( $post_id, '_ppr_proposal_items', true );
    $total_price = 0;
    $pdf->SetFont('Arial','',10);
    $fill = false; 
    $row_min_height = 8; 
    $line_height_ratio = 5; 

    if ( ! empty( $line_items ) && is_array( $line_items ) ) {
        foreach ( $line_items as $item ) {
            $start_x = 20; 
            $pdf->SetX($start_x);
            
            // Set fill color for the row
            $pdf->SetFillColor(255, 255, 255); 
            if ($fill) { $pdf->SetFillColor(248, 248, 248); } 
            
            // Get item data
            $item_description = isset($item['description']) ? $item['description'] : '';
            $item_description_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($item_description, 'ISO-8859-1', 'UTF-8') : $item_description; 
            $item_qty = isset($item['quantity']) ? max(1, intval($item['quantity'])) : 1; 
            $item_unit_price = isset($item['price']) ? floatval($item['price']) : 0;
            $item_line_total = $item_qty * $item_unit_price;
            $total_price += $item_line_total;

            // Calculate Row Height based on Description
            $start_y = $pdf->GetY();
            $desc_width = $content_width * 0.6;
            $pdf->MultiCell($desc_width, $line_height_ratio, $item_description_iso, 0, 'L'); 
            $desc_end_y = $pdf->GetY();
            $calculated_desc_height = $desc_end_y - $start_y;
            $current_row_height = max($row_min_height, $calculated_desc_height); 
            
            // Reset Y position to start drawing the row
            $pdf->SetXY($start_x, $start_y);
            
            // Check for page break BEFORE drawing the row content
            if($start_y + $current_row_height > $pdf->GetPageHeight() - 30) { 
                 $pdf->AddPage();
                 // Redraw headers on new page
                 $pdf->SetY(20);
                 $pdf->SetFont('Arial','B',10);
                 $pdf->SetFillColor(220, 220, 220); $pdf->SetTextColor(40, 40, 40); $pdf->SetDrawColor(180, 180, 180); $pdf->SetLineWidth(0.3);
                 $pdf->Cell($content_width * 0.6, $header_height, 'Description', 1, 0, 'L', true);
                 $pdf->Cell($content_width * 0.1, $header_height, 'Qty', 1, 0, 'C', true);
                 $pdf->Cell($content_width * 0.15, $header_height, 'Unit Price', 1, 0, 'R', true);
                 $pdf->Cell($content_width * 0.15, $header_height, 'Total', 1, 1, 'R', true);
                 $pdf->SetTextColor(0, 0, 0); $pdf->SetLineWidth(0.2); $pdf->SetDrawColor(200, 200, 200); $pdf->SetFont('Arial','',10);
                 $start_y = $pdf->GetY(); 
                 $pdf->SetXY($start_x, $start_y);
            } 
            
            // Draw Row Cells with full borders (1) and fill
            $border = 1; // << Use full border (1) consistently
            $multi_cell_border = $border; 

            // Description (MultiCell)
            $pdf->MultiCell($desc_width, $line_height_ratio, $item_description_iso, $multi_cell_border, 'L', $fill); 
            $pdf->SetXY($start_x + $desc_width, $start_y); 

            // Quantity
            $qty_width = $content_width * 0.1;
            $pdf->Cell($qty_width, $current_row_height, $item_qty, $border, 0, 'C', $fill);

            // Unit Price
            $unit_price_width = $content_width * 0.15;
            $unit_price_text = $currency_symbol . number_format($item_unit_price, 2);
            $unit_price_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($unit_price_text, 'ISO-8859-1', 'UTF-8') : $unit_price_text; 
            $pdf->Cell($unit_price_width, $current_row_height, $unit_price_text_iso, $border, 0, 'R', $fill);

            // Line Total
            $line_total_width = $content_width * 0.15;
            $line_total_text = $currency_symbol . number_format($item_line_total, 2);
            $line_total_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($line_total_text, 'ISO-8859-1', 'UTF-8') : $line_total_text;
            $pdf->Cell($line_total_width, $current_row_height, $line_total_text_iso, $border, 1, 'R', $fill); // << Use ln=1 here to move to next line automatically

            // Y position is now automatically below the row just drawn due to ln=1 in the last Cell
            // $pdf->SetY($start_y + $current_row_height); // << No longer necessary

            $fill = !$fill; 
        }
        // No need for extra bottom line here, as cells have full borders
        $current_y = $pdf->GetY(); // Y position after the loop finishes

    } else {
        // Handle case with no items
        $pdf->SetX(20);
        $no_items_text = __( 'No pricing items defined.', 'pretty-proposals' );
        $no_items_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($no_items_text, 'ISO-8859-1', 'UTF-8') : $no_items_text;
        $pdf->Cell($content_width, 10, $no_items_text_iso, 1, 1, 'C'); // Keep border for this message cell
        $current_y = $pdf->GetY() + 5;
    }


    // --- Total Section --- 
    $pdf->SetY($current_y); 
    $pdf->SetX(20 + $content_width * 0.7); // Align with price columns
    $pdf->SetFont('Arial','B',10);
    $pdf->SetFillColor(220, 220, 220); // Match header color
    $pdf->SetTextColor(40, 40, 40); // Match header text color
    $pdf->SetLineWidth(0.3);
    $pdf->Cell($content_width * 0.15, $header_height, 'TOTAL', 1, 0, 'R', true); 
    $overall_total_text = $currency_symbol . number_format($total_price, 2);
    $overall_total_text_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($overall_total_text, 'ISO-8859-1', 'UTF-8') : $overall_total_text;
    $pdf->Cell($content_width * 0.15, $header_height, $overall_total_text_iso, 1, 1, 'R', true); 
    $pdf->SetTextColor(0, 0, 0); // Reset text color
    $pdf->SetLineWidth(0.2); // Reset line width
    $current_y = $pdf->GetY() + 15;


    // --- Payment Terms & Banking Details ---
    $pdf->SetY($current_y);
    $pdf->SetFont('Arial','B',11); 
    $pdf->SetTextColor(80, 80, 80); // Medium grey heading
    if ($payment_terms) {
        $pdf->Cell(0, 7, 'Payment Terms', 0, 1, 'L');
        $pdf->SetFont('Arial','',10);
        $pdf->SetTextColor(0, 0, 0); // Black text
        $payment_terms_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($payment_terms, 'ISO-8859-1', 'UTF-8') : $payment_terms;
        $pdf->MultiCell(0, 5, $payment_terms_iso, 0, 'L');
        $pdf->Ln(8); // More space
        $current_y = $pdf->GetY();
    }
    
    $pdf->SetY($current_y);
    if ($banking_details) {
        $pdf->SetFont('Arial','B',11);
        $pdf->SetTextColor(80, 80, 80);
        $pdf->Cell(0, 7, 'Payment Details', 0, 1, 'L');
        $pdf->SetFont('Arial','',10);
        $pdf->SetTextColor(0, 0, 0);
        $banking_details_iso = function_exists('mb_convert_encoding') ? mb_convert_encoding($banking_details, 'ISO-8859-1', 'UTF-8') : $banking_details;
        $pdf->MultiCell(0, 5, $banking_details_iso, 0, 'L');
    }

    // --- Output PDF --- 
    try {
        if ( $output_mode === 'D' ) {
            // Force download
            $pdf->Output( 'D', $pdf_filename );
            exit; // Ensure script termination after download header
        } else {
            // Save to file (original behavior)
            $upload_dir = wp_upload_dir();
            $pdf_dir = $upload_dir['basedir'] . '/pretty-proposals/invoices'; 
            if ( ! file_exists( $pdf_dir ) ) {
                wp_mkdir_p( $pdf_dir );
            }
            $filepath = $pdf_dir . '/' . $pdf_filename;
            $pdf->Output( 'F', $filepath );
            // Check if file exists after trying to save
            if ( ! file_exists( $filepath ) ) {
                 return new WP_Error( 'pdf_save_failed', __( 'FPDF failed to save the file to the specified path.', 'pretty-proposals' ) );
            }
            return $filepath; // Return the filepath on successful save
        }
    } catch (Exception $e) {
        error_log("FPDF Output Error: " . $e->getMessage());
        return new WP_Error('pdf_output_failed', 'Failed to output PDF: ' . $e->getMessage());
    }
    // Code should not reach here in normal operation due to return/exit in try block
    return new WP_Error('pdf_logic_error', 'Reached unexpected end of PDF generation function.');
}

// --- Handle Invoice Download ---

/**
 * Handles the request to download an invoice PDF.
 * Hooked to admin_post_ppr_download_invoice.
 */
function ppr_handle_download_invoice() {
    // 1. Check if proposal ID is provided
    if ( ! isset( $_GET['proposal_id'] ) || ! is_numeric( $_GET['proposal_id'] ) ) {
        wp_die( __( 'Invalid Proposal ID.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 400 );
    }
    $proposal_id = intval( $_GET['proposal_id'] );

    // 2. Verify Nonce
    if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_key($_GET['_wpnonce']), 'ppr_download_invoice_' . $proposal_id ) ) {
        wp_die( __( 'Security check failed. Please try again.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 403 );
    }

    // 3. Verify User Permissions
    if ( ! current_user_can( 'edit_post', $proposal_id ) ) {
         wp_die( __( 'You do not have permission to access this invoice.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 403 );
    }

    // 4. Verify Post Type and Status
    $post = get_post( $proposal_id );
    if ( ! $post || $post->post_type !== 'pretty_proposal' ) {
        wp_die( __( 'Invalid proposal specified.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 404 );
    }
    $status = get_post_meta( $proposal_id, '_ppr_proposal_status', true );
    // Allow download only if accepted (or maybe sent?) - let's stick to accepted for now.
    if ( $status !== 'accepted' ) {
         wp_die( __( 'Invoice can only be downloaded for accepted proposals.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 403 );
    }


    // 5. Generate and Output PDF
    $result = ppr_generate_invoice_pdf( $proposal_id, 'D' ); // Use 'D' for download

    // 6. Handle potential errors from PDF generation
    if ( is_wp_error( $result ) ) {
        wp_die( sprintf(__( 'Failed to generate invoice PDF: %s', 'pretty-proposals' ), $result->get_error_message()), __( 'Invoice Generation Error', 'pretty-proposals' ), 500 );
    } elseif ( $result !== true ) { // Check should return true on success for 'D' mode
         wp_die( __( 'An unknown error occurred while generating the invoice PDF.', 'pretty-proposals' ), __( 'Invoice Generation Error', 'pretty-proposals' ), 500 );
    }

    // 7. Ensure no further output
    exit;
}
add_action( 'admin_post_ppr_download_invoice', 'ppr_handle_download_invoice' );


// --- Email Sending ---

/**
 * Send the proposal PDF via email to the client.
 *
 * @param int $post_id The ID of the proposal post.
 * @return bool|WP_Error True on success, WP_Error on failure.
 */
function ppr_send_proposal_email( $post_id ) {

    // Generate the PDF first using renamed function
    $pdf_filepath = ppr_generate_proposal_pdf( $post_id );

    // Check if PDF generation was successful
    if ( is_wp_error( $pdf_filepath ) ) {
        // PDF generation failed, return the error
        return $pdf_filepath;
    }

    // Get proposal data needed for email
    $post = get_post( $post_id );
    if ( ! $post || $post->post_type !== 'pretty_proposal' ) { // Check new CPT slug
        if ( file_exists( $pdf_filepath ) ) { unlink( $pdf_filepath ); } // Clean up PDF
        return new WP_Error( 'invalid_post', __( 'Invalid proposal ID provided for email.', 'pretty-proposals' ) );
    }

    // Get renamed meta keys
    $client_email   = get_post_meta( $post_id, '_ppr_client_email', true );
    $proposal_title = $post->post_title;
    $client_name    = get_post_meta( $post_id, '_ppr_client_name', true ); // For personalization
    $proposal_key   = get_post_meta( $post_id, '_ppr_proposal_key', true ); // Get the key

    // Validate client email
    if ( ! is_email( $client_email ) ) {
        if ( file_exists( $pdf_filepath ) ) { unlink( $pdf_filepath ); } // Clean up PDF
        return new WP_Error( 'invalid_email', __( 'Invalid client email address provided.', 'pretty-proposals' ) );
    }

    // --- Prepare Email ---

    // Subject Line
    $subject = sprintf(
        /* translators: %s: Proposal Title */
        __( 'Proposal: %s', 'pretty-proposals' ),
        $proposal_title
    );

    // Email Body (HTML)
    // Use renamed option key
    $options = get_option( 'ppr_settings' );
    $email_template = isset( $options['email_body'] ) && !empty( $options['email_body'] ) ? $options['email_body'] : ppr_get_default_email_body(); // Use renamed helper

    // Replace placeholders
    $proposal_link_html = '';
    if ( $proposal_key && $post->post_status === 'publish' ) {
        $proposal_url = home_url( '/proposal/' . $post_id . '/' . $proposal_key . '/' );
        // Create an HTML link
        $proposal_link_html = sprintf(
            '<a href="%s">%s</a>',
            esc_url($proposal_url),
            __( 'View Proposal Online', 'pretty-proposals' )
        );
    } else {
        // Optional: Add a message if link isn't ready (e.g., proposal not published)
        // $proposal_link_html = '(' . __( 'Link available once proposal is published', 'pretty-proposals' ) . ')';
    }

    // Get Company Name for replacement
    $company_name_setting = isset($options['company_name']) ? $options['company_name'] : get_bloginfo('name'); // Fallback to site name if company name not set
    $your_name_setting = isset($options['from_name']) ? $options['from_name'] : $company_name_setting; // Use From Name if set, else Company Name

    $replacements = array(
        '{client_name}'    => $client_name ? esc_html( $client_name ) : __( 'Valued Client', 'pretty-proposals' ), // Fallback if name is empty
        '{proposal_title}' => esc_html( $proposal_title ),
        '{site_name}'      => esc_html( get_bloginfo( 'name' ) ), 
        // '{company_name}'   => esc_html( $company_name_setting ), // Deprecated, use your_company_name
        '{proposal_link_html}' => $proposal_link_html,
        // Add the missing replacements
        '{your_name}'         => esc_html( $your_name_setting ),
        '{your_company_name}' => esc_html( $company_name_setting ),
    );
    $message = str_replace( array_keys( $replacements ), array_values( $replacements ), $email_template );

    // Headers
    // $options = get_option( 'ppr_settings' ); // Already fetched above
    $from_name = ! empty( $options['from_name'] ) ? $options['from_name'] : get_bloginfo( 'name' );
    $from_email = ! empty( $options['from_email'] ) && is_email( $options['from_email'] ) ? $options['from_email'] : get_option( 'admin_email' );

    $headers = array();
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    // Optional: Set Reply-To to the same custom address, or make it another setting?
    // $headers[] = 'Reply-To: ' . $from_name . ' <' . $from_email . '>';

    // Attachments
    $attachments = array( $pdf_filepath );

    // --- Send Email ---
    $sent = wp_mail( $client_email, $subject, $message, $headers, $attachments );

    // --- Clean Up ---
    if ( file_exists( $pdf_filepath ) ) {
        unlink( $pdf_filepath );
    }

    // Check if email was sent successfully
    if ( ! $sent ) {
        global $phpmailer;
        $error_message = __( 'The email could not be sent.', 'pretty-proposals' );
        if ( isset( $phpmailer ) && $phpmailer instanceof PHPMailer\PHPMailer\PHPMailer ) {
             // Add PHPMailer error info if available (requires WP 5.5+)
             $error_message .= ' ' . $phpmailer->ErrorInfo;
        }
        return new WP_Error( 'email_failed', $error_message );
    }

    return true; // Email sent successfully
}

/**
 * Generate a unique invoice number.
 * Simple approach: Prefix + Proposal Number or Post ID.
 *
 * @param int $post_id The ID of the proposal post.
 * @return string The generated invoice number.
 */
function ppr_generate_unique_invoice_number( $post_id ) {
    $proposal_number = get_post_meta( $post_id, '_ppr_proposal_number', true );
    if ( ! empty( $proposal_number ) ) {
        // Use proposal number if available
        $invoice_number = 'INV-' . $proposal_number;
    } else {
        // Fallback to post ID
        $invoice_number = 'INV-' . $post_id . '-' . date('Ymd'); // Add date for more uniqueness
    }
    // Potential future enhancement: Check if this number truly exists and add suffix if needed.
    return $invoice_number;
}

/**
 * Send the invoice PDF via email to the client.
 *
 * @param int $post_id The ID of the proposal post (which the invoice is based on).
 * @return bool|WP_Error True on success, WP_Error on failure.
 */
function ppr_send_invoice_email( $post_id ) {

    // Generate the Invoice PDF first
    $pdf_filepath = ppr_generate_invoice_pdf( $post_id );

    // Check if PDF generation was successful
    if ( is_wp_error( $pdf_filepath ) ) {
        error_log("Invoice PDF Generation Error for Post {$post_id}: " . $pdf_filepath->get_error_message());
        return $pdf_filepath; // Return the error
    }

    // Get proposal/client data needed for email
    $post = get_post( $post_id );
    if ( ! $post || $post->post_type !== 'pretty_proposal' ) {
        if ( file_exists( $pdf_filepath ) ) { unlink( $pdf_filepath ); } // Clean up PDF
        return new WP_Error( 'invalid_post', __( 'Invalid proposal ID provided for invoice email.', 'pretty-proposals' ) );
    }

    $client_email   = get_post_meta( $post_id, '_ppr_client_email', true );
    $proposal_title = $post->post_title;
    $client_name    = get_post_meta( $post_id, '_ppr_client_name', true );
    $proposal_number = get_post_meta( $post_id, '_ppr_proposal_number', true );
    $invoice_number = 'INV-' . ($proposal_number ?: $post_id);

    // Validate client email
    if ( ! is_email( $client_email ) ) {
        if ( file_exists( $pdf_filepath ) ) { unlink( $pdf_filepath ); } // Clean up PDF
        return new WP_Error( 'invalid_email', __( 'Invalid client email address for invoice.', 'pretty-proposals' ) );
    }

    // --- Prepare Email ---
    $options = get_option( 'ppr_settings' );
    $company_name = isset($options['company_name']) ? $options['company_name'] : get_bloginfo('name');

    // --- Get Email Settings and Content ---
    $email_subject = isset($options['invoice_email_subject']) && !empty($options['invoice_email_subject']) 
                       ? $options['invoice_email_subject'] 
                       : 'Invoice for {proposal_title}'; // Default Subject
    $email_body = isset($options['invoice_email_body']) && !empty(trim($options['invoice_email_body']))
                     ? $options['invoice_email_body'] 
                     : ppr_get_default_invoice_email_body(); // Use setting or default body
    
    $your_name = isset($options['company_name']) ? $options['company_name'] : get_bloginfo( 'name' ); // Use Company Name if set, else Site Name
    $your_company_name = isset($options['company_name']) ? $options['company_name'] : get_bloginfo( 'name' );

    // --- Replace Placeholders ---
    $proposal_title = $post->post_title;
    $invoice_number = get_post_meta( $post_id, '_ppr_invoice_number', true );
    if ( ! $invoice_number ) { // Generate if missing (should have been done earlier, but fallback)
        $invoice_number = ppr_generate_unique_invoice_number( $post_id );
        update_post_meta( $post_id, '_ppr_invoice_number', $invoice_number );
    }

    $subject = str_replace( '{client_name}', $client_name, $email_subject );
    $subject = str_replace( '{proposal_title}', $proposal_title, $subject );
    $subject = str_replace( '{invoice_number}', $invoice_number, $subject );
    $subject = str_replace( '{your_name}', $your_name, $subject ); // Placeholder in subject?
    $subject = str_replace( '{your_company_name}', $your_company_name, $subject );
    $subject = str_replace( '{site_name}', get_bloginfo( 'name' ), $subject );
    
    $body = str_replace( '{client_name}', $client_name, $email_body );
    $body = str_replace( '{proposal_title}', $proposal_title, $body );
    $body = str_replace( '{invoice_number}', $invoice_number, $body );
    $body = str_replace( '{your_name}', $your_name, $body );
    $body = str_replace( '{your_company_name}', $your_company_name, $body );
    $body = str_replace( '{site_name}', get_bloginfo( 'name' ), $body );

    // --- Generate Invoice PDF if it doesn't exist ---
    // $invoice_pdf_path = ppr_get_invoice_pdf_path( $post_id ); // << REMOVE THIS ERRONEOUS CALL

    // --- Prepare Email ---
    $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
    // Add sender info if configured
    $company_name = isset($options['company_name']) ? $options['company_name'] : get_bloginfo('name');
    $company_email = isset($options['company_email']) ? $options['company_email'] : get_option('admin_email');
    $headers[] = 'From: "' . $company_name . '" <' . $company_email . '>';

    // --- Set Attachments --- // << ENSURE THIS USES THE CORRECT PATH
    $attachments = array( $pdf_filepath ); // Use the path returned by ppr_generate_invoice_pdf()

    // --- Send Email ---
    $sent = wp_mail( $client_email, $subject, nl2br( $body ), $headers, $attachments );

    // --- Logging ---
    if ( ! $sent ) {
        error_log("Invoice Email Sending Error for Post {$post_id}: Could not send email. Subject: {$subject}");
        return new WP_Error( 'email_failed', __( 'Failed to send invoice email.', 'pretty-proposals' ) );
    }

    return true; // Email sent successfully
}

// --- Admin Assets & AJAX Handler ---

/**
 * Enqueue admin scripts and styles.
 */
function ppr_enqueue_admin_assets( $hook_suffix ) {
    global $post_type;

    // Only load on proposal edit screens or the proposal list view
    $load_assets = false;
    // Check new CPT slug
    if ($post_type === 'pretty_proposal') {
        if ( $hook_suffix == 'post-new.php' || $hook_suffix == 'post.php' ) {
             $load_assets = true;
        } elseif ( $hook_suffix == 'edit.php' ) { // Check if it's the list view for proposals
            $screen = get_current_screen();
            // Check new screen ID
            if ( $screen && $screen->id === 'edit-pretty_proposal') {
                $load_assets = true;
            }
        }
    }

    if ( $load_assets ) {

        // Ensure the js directory exists
        if (!is_dir(plugin_dir_path( __FILE__ ) . 'js')) {
            mkdir(plugin_dir_path( __FILE__ ) . 'js');
        }
         // Ensure the css directory exists
        if (!is_dir(plugin_dir_path( __FILE__ ) . 'css')) {
            mkdir(plugin_dir_path( __FILE__ ) . 'css');
        }

        // Enqueue Script (only needed on edit screens)
        if ( $hook_suffix == 'post-new.php' || $hook_suffix == 'post.php' ) {
            wp_enqueue_script(
                'ppr-admin-script', // Renamed handle
                plugin_dir_url( __FILE__ ) . 'js/admin-proposals.js',
                array( 'jquery' ), // Dependency
                '1.0.0',           // Version
                true              // Load in footer
            );

            // Localize script to pass data (Renamed object)
            wp_localize_script( 'ppr-admin-script', 'ppr_ajax', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'send_nonce' => wp_create_nonce( 'ppr_send_proposal_action' ), // Renamed nonce action
                'sending_text' => __( 'Sending...', 'pretty-proposals' ),
                'error_prefix' => __( 'Error:', 'pretty-proposals' ),
                'success_message' => __( 'Proposal sent successfully!', 'pretty-proposals' ),
            ) );
        }

        // Enqueue Style (needed on list and edit screens)
        wp_enqueue_style(
            'ppr-admin-style', // Renamed handle
            plugin_dir_url( __FILE__ ) . 'css/admin-proposals.css',
            array(), // Dependencies
            '1.0.0'  // Version
        );
    }
}
add_action( 'admin_enqueue_scripts', 'ppr_enqueue_admin_assets' );

/**
 * Handles the AJAX request for sending the proposal.
 */
function ppr_ajax_send_proposal_handler() {
    // 1. Check Nonce (Renamed nonce action)
    check_ajax_referer( 'ppr_send_proposal_action', 'nonce' );

    // 2. Check User Permissions
    if ( ! isset( $_POST['post_id'] ) || ! current_user_can( 'edit_post', intval( $_POST['post_id'] ) ) ) {
        wp_send_json_error( __( 'Permission denied.', 'pretty-proposals' ) );
    }

    // 3. Get Post ID
    $post_id = intval( $_POST['post_id'] );
    if ( ! $post_id || get_post_type( $post_id ) !== 'pretty_proposal' ) { // Check new CPT slug
        wp_send_json_error( __( 'Invalid proposal ID.', 'pretty-proposals' ) );
    }

    // 4. Attempt to send the email (Renamed function)
    $result = ppr_send_proposal_email( $post_id );

    // 5. Handle Result
    if ( is_wp_error( $result ) ) {
        // Send error details back to JavaScript
        wp_send_json_error( $result->get_error_message() );
    } else if ( $result === true ) {
        // Success! Update status to 'sent' (Renamed meta key)
        update_post_meta( $post_id, '_ppr_proposal_status', 'sent' );
        wp_send_json_success( array( 'message' => __( 'Proposal sent successfully!', 'pretty-proposals' ) ) );
    } else {
        // Unknown error
        wp_send_json_error( __( 'An unknown error occurred during sending.', 'pretty-proposals' ) );
    }

    // wp_send_json_* functions include wp_die()
}
// Renamed AJAX action hook
add_action( 'wp_ajax_ppr_send_proposal', 'ppr_ajax_send_proposal_handler' );

// --- Admin List View Customizations ---

/**
 * Add custom columns to the proposal list table.
 *
 * @param array $columns Existing columns.
 * @return array Modified columns.
 */
function ppr_add_proposal_admin_columns( $columns ) {
    // Add new columns and rearrange
    $new_columns = array();
    foreach ($columns as $key => $title) {
        $new_columns[$key] = $title;
        if ($key == 'title') { // Add our columns after the title
            // Renamed column keys
            $new_columns['ppr_client_name'] = __( 'Client Name', 'pretty-proposals' );
            $new_columns['ppr_proposal_status'] = __( 'Status', 'pretty-proposals' );
        }
    }
    // Optional: Remove columns we don't need (like date?)
    // unset($new_columns['date']);
    return $new_columns;
}
// Renamed filter hook
add_filter( 'manage_edit-pretty_proposal_columns', 'ppr_add_proposal_admin_columns' );

/**
 * Display content for custom proposal columns.
 *
 * @param string $column_name The name of the column to display.
 * @param int    $post_id     The current post ID.
 */
function ppr_display_proposal_admin_column_content( $column_name, $post_id ) {
    // Check renamed column keys and use renamed meta keys
    switch ( $column_name ) {
        case 'ppr_client_name':
            $client_name = get_post_meta( $post_id, '_ppr_client_name', true );
            echo esc_html( $client_name ? $client_name : '--' );
            break;

        case 'ppr_proposal_status':
            $status = get_post_meta( $post_id, '_ppr_proposal_status', true );
            if ( empty( $status ) ) {
                $status = 'draft'; // Default if not set
            }
            // Make status more readable
            $status_label = ucwords( str_replace( '_', ' ', $status ) ); // Capitalize words
            // Optional: Add some basic styling based on status
            $style = '';
            if ($status === 'sent') $style = 'color: orange;';
            if ($status === 'accepted') $style = 'color: green;';
            if ($status === 'rejected') $style = 'color: red;';
            if ($status === 'draft') $style = 'color: grey;';

            echo '<span style="' . esc_attr($style) . '; font-weight: bold;">' . esc_html( $status_label ) . '</span>';
            break;
    }
}
// Renamed action hook
add_action( 'manage_pretty_proposal_posts_custom_column', 'ppr_display_proposal_admin_column_content', 10, 2 );

// --- Settings Page ---

/**
 * Add Settings submenu page under Proposals.
 */
function ppr_add_settings_page() {
    add_submenu_page(
        'edit.php?post_type=pretty_proposal', // Parent slug (using new CPT slug)
        __( 'Proposal Settings', 'pretty-proposals' ), // Page title
        __( 'Settings', 'pretty-proposals' ),       // Menu title
        'manage_options',                  // Capability required
        'ppr-settings',                    // Menu slug (Renamed)
        'ppr_render_settings_page'         // Callback function to render the page (Renamed)
    );
}
add_action( 'admin_menu', 'ppr_add_settings_page' );

/**
 * Register plugin settings using the Settings API.
 */
function ppr_register_settings() {
    // Register a settings group (Renamed)
    register_setting( 'ppr_settings_group', 'ppr_settings', 'ppr_sanitize_settings' ); // Renamed option name & sanitize callback

    // Add settings section for Company Info
    add_settings_section(
        'ppr_company_info_section',
        __( 'Your Company Information', 'pretty-proposals' ),
        'ppr_company_info_section_callback', // New callback
        'ppr-settings' // Page slug
    );

    // Add fields to Company Info section
     add_settings_field(
        'ppr_company_name',
        __( 'Company Name', 'pretty-proposals' ),
        'ppr_company_name_render', // New callback
        'ppr-settings', 
        'ppr_company_info_section' 
    );
     add_settings_field(
        'ppr_company_address',
        __( 'Company Address', 'pretty-proposals' ),
        'ppr_company_address_render', // New callback
        'ppr-settings', 
        'ppr_company_info_section' 
    );
     add_settings_field(
        'ppr_company_phone',
        __( 'Company Phone', 'pretty-proposals' ),
        'ppr_company_phone_render', // New callback
        'ppr-settings', 
        'ppr_company_info_section' 
    );
     add_settings_field(
        'ppr_company_email',
        __( 'Company Email', 'pretty-proposals' ),
        'ppr_company_email_render', // New callback
        'ppr-settings', 
        'ppr_company_info_section' 
    );

    // Add settings section for Email Settings (Renamed IDs)
    add_settings_section(
        'ppr_email_settings_section',
        __( 'Email Sender Settings', 'pretty-proposals' ),
        'ppr_email_settings_section_callback', // Renamed callback
        'ppr-settings' // Page slug where this section should appear (Renamed)
    );

    // Add fields to the Email Settings section (Renamed IDs & callbacks)
    add_settings_field(
        'ppr_from_name',
        __( 'From Name', 'pretty-proposals' ),
        'ppr_from_name_render', // Renamed callback
        'ppr-settings', // Renamed page slug
        'ppr_email_settings_section' // Renamed section ID
    );

    add_settings_field(
        'ppr_from_email',
        __( 'From Email', 'pretty-proposals' ),
        'ppr_from_email_render', // Renamed callback
        'ppr-settings', // Renamed page slug
        'ppr_email_settings_section' // Renamed section ID
    );

    // Add Email Body field (Renamed IDs & callback)
     add_settings_field(
        'ppr_email_body',
        __( 'Email Body Template', 'pretty-proposals' ),
        'ppr_email_body_render', // Renamed callback
        'ppr-settings', // Renamed page slug
        'ppr_email_settings_section' // Renamed section ID
    );

    // Add settings section for PDF Settings (Renamed IDs & callback)
    add_settings_section(
        'ppr_pdf_settings_section',
        __( 'PDF Settings', 'pretty-proposals' ),
        'ppr_pdf_settings_section_callback', // Renamed callback
        'ppr-settings' // Renamed page slug
    );

    // Add Company Logo field (Renamed IDs & callback)
     add_settings_field(
        'ppr_company_logo',
        __( 'Company Logo', 'pretty-proposals' ),
        'ppr_company_logo_render', // Renamed callback
        'ppr-settings', // Renamed page slug
        'ppr_pdf_settings_section' // Renamed section ID
    );

    // Add settings section for Invoicing
    add_settings_section(
        'ppr_invoice_settings_section',
        __( 'Invoicing Details', 'pretty-proposals' ),
        'ppr_invoice_settings_section_callback', // New callback
        'ppr-settings' // Page slug
    );

    // Add fields to Invoicing section
     add_settings_field(
        'ppr_payment_terms',
        __( 'Payment Terms', 'pretty-proposals' ),
        'ppr_payment_terms_render', // New callback
        'ppr-settings',
        'ppr_invoice_settings_section'
    );
     add_settings_field(
        'ppr_banking_details',
        __( 'Banking Details', 'pretty-proposals' ),
        'ppr_banking_details_render', // New callback
        'ppr-settings',
        'ppr_invoice_settings_section'
    );

     add_settings_field(
        'ppr_currency_symbol',
        __( 'Currency Symbol', 'pretty-proposals' ),
        'ppr_currency_symbol_render', // New callback
        'ppr-settings',
        'ppr_invoice_settings_section'
    );

     add_settings_field(
        'ppr_invoice_email_body', // New setting ID
        __( 'Invoice Email Body Template', 'pretty-proposals' ),
        'ppr_invoice_email_body_render', // New render callback
        'ppr-settings',
        'ppr_invoice_settings_section' // Add to invoice section
    );

     add_settings_field(
        'ppr_invoice_due_days', // New ID
        __( 'Payment Due Days', 'pretty-proposals' ),
        'ppr_invoice_due_days_render', // New callback
        'ppr-settings',
        'ppr_invoice_settings_section'
    );

}
add_action( 'admin_init', 'ppr_register_settings' );

/**
 * Callback function for the email settings section description (optional).
 */
function ppr_email_settings_section_callback() {
    echo __( 'Configure the name and email address used when sending proposal emails.', 'pretty-proposals' );
}

/**
 * Callback function for the Company Info section description.
 */
function ppr_company_info_section_callback() {
    echo __( 'Enter your company details. This information will be displayed on generated PDFs.', 'pretty-proposals' );
}

/**
 * Render the input field for 'Company Name'.
 */
function ppr_company_name_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['company_name'] ) ? $options['company_name'] : '';
    echo '<input type="text" name="ppr_settings[company_name]" value="' . esc_attr( $value ) . '" class="regular-text" />';
}

/**
 * Render the textarea field for 'Company Address'.
 */
function ppr_company_address_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['company_address'] ) ? $options['company_address'] : '';
    echo '<textarea name="ppr_settings[company_address]" rows="5" cols="50" class="large-text">' . esc_textarea( $value ) . '</textarea>';
    echo '<p class="description">' . __( 'Enter your full company address, one part per line.', 'pretty-proposals' ) . '</p>';
}

/**
 * Render the input field for 'Company Phone'.
 */
function ppr_company_phone_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['company_phone'] ) ? $options['company_phone'] : '';
    echo '<input type="text" name="ppr_settings[company_phone]" value="' . esc_attr( $value ) . '" class="regular-text" />';
}

/**
 * Render the input field for 'Company Email'.
 */
function ppr_company_email_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['company_email'] ) ? $options['company_email'] : '';
    echo '<input type="email" name="ppr_settings[company_email]" value="' . esc_attr( $value ) . '" class="regular-text" />';
}

/**
 * Render the input field for 'From Name'.
 */
function ppr_from_name_render() {
    $options = get_option( 'ppr_settings' ); // Renamed option
    $from_name = isset( $options['from_name'] ) ? $options['from_name'] : '';
    $default_from_name = get_bloginfo( 'name' );
    // Use renamed option key in name attribute
    echo '<input type="text" name="ppr_settings[from_name]" value="' . esc_attr( $from_name ) . '" class="regular-text" placeholder="' . esc_attr( $default_from_name ). '" />';
    echo '<p class="description">' . sprintf(__( 'Defaults to site name: %s', 'pretty-proposals'), esc_html($default_from_name)) . '</p>';
}

/**
 * Render the input field for 'From Email'.
 */
function ppr_from_email_render() {
    $options = get_option( 'ppr_settings' ); // Renamed option
    $from_email = isset( $options['from_email'] ) ? $options['from_email'] : '';
    $default_from_email = get_option( 'admin_email' );
     // Use renamed option key in name attribute
    echo '<input type="email" name="ppr_settings[from_email]" value="' . esc_attr( $from_email ) . '" class="regular-text" placeholder="' . esc_attr( $default_from_email ). '" />';
     echo '<p class="description">' . sprintf(__( 'Defaults to site admin email: %s', 'pretty-proposals'), esc_html($default_from_email)) . '</p>';
}

/**
 * Render the textarea field for 'Email Body Template'.
 */
function ppr_email_body_render() {
    $options = get_option( 'ppr_settings' ); // Renamed option
    $email_body = isset( $options['email_body'] ) ? $options['email_body'] : ppr_get_default_email_body(); // Use renamed helper

    // Use renamed option key in name attribute
    echo '<textarea name="ppr_settings[email_body]" rows="10" cols="50" class="large-text code">' . esc_textarea( $email_body ) . '</textarea>';
    echo '<p class="description">' . __( 'Customize the body of the email sent to the client. Available placeholders:', 'pretty-proposals' ) . '</p>';
    echo '<ul style="list-style: disc; margin-left: 20px;">';
    echo '<li><code>{client_name}</code> - ' . __( 'Client\'s Name', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{proposal_title}</code> - ' . __( 'Proposal Title', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{site_name}</code> - ' . __( 'Your Site Name (can be used in template)', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{company_name}</code> - ' . __( 'Your Company Name (from settings)', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{proposal_link_html}</code> - ' . __( 'Link to view the proposal online (HTML anchor tag)', 'pretty-proposals' ) . '</li>';
    echo '</ul>';
}

/**
 * Helper function to get the default email body text.
 *
 * @return string Default email body.
 */
function ppr_get_default_email_body() {
    // Use nl2br compatible format
    return "Dear {client_name},

Please find attached the proposal for: {proposal_title}.

Please review the details and respond via the link below:

{proposal_link_html}

If you have any questions, please don't hesitate to reach out.

Thank you,
{your_name}
{your_company_name}";
}

/**
 * Callback function for the PDF settings section description (optional).
 */
function ppr_pdf_settings_section_callback() {
    echo __( 'Customize the appearance of the generated PDF proposals.', 'pretty-proposals' );
}

/**
 * Render the input field for 'Company Logo'.
 */
function ppr_company_logo_render() {
    $options = get_option( 'ppr_settings' ); // Renamed option
    $logo_id = isset( $options['company_logo_id'] ) ? $options['company_logo_id'] : 0;
    $logo_url = $logo_id ? wp_get_attachment_url( $logo_id ) : '';

    // Enqueue media scripts
    wp_enqueue_media();

    // Renamed CSS classes and IDs
    echo '<div class="ppr-logo-uploader">';
    echo '<input type="hidden" name="ppr_settings[company_logo_id]" id="ppr_company_logo_id" value="' . esc_attr( $logo_id ) . '" />';
    echo '<button type="button" class="button ppr-upload-logo-button">' . __( 'Upload/Select Logo', 'pretty-proposals' ) . '</button>';
    echo '<button type="button" class="button ppr-remove-logo-button"' . ( !$logo_id ? ' style="display:none;"' : '' ) . '>' . __( 'Remove Logo', 'pretty-proposals' ) . '</button>';
    echo '<div class="ppr-logo-preview" style="margin-top: 10px;">';
    if ( $logo_url ) {
        echo '<img src="' . esc_url( $logo_url ) . '" style="max-width: 200px; max-height: 100px; border: 1px solid #ddd; padding: 5px;" />';
    }
    echo '</div>';
    echo '</div>';
    echo '<p class="description">' . __( 'Upload or select a logo from the Media Library to display at the top of your PDF proposals.', 'pretty-proposals' ) . '</p>';

    // Add some inline JS for the media uploader (Using renamed classes/IDs)
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($){
            var mediaUploader;
            // Use renamed class selector
            $('.ppr-upload-logo-button').click(function(e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media.frames.file_frame = wp.media({
                    title: '<?php echo esc_js( __( "Choose Logo", "pretty-proposals" ) ); ?>',
                    button: {
                        text: '<?php echo esc_js( __( "Choose Logo", "pretty-proposals" ) ); ?>'
                    },
                    multiple: false
                });
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    // Use renamed ID selector
                    $('#ppr_company_logo_id').val(attachment.id);
                    // Use renamed class selector
                    $('.ppr-logo-preview').html('<img src="' + attachment.url + '" style="max-width: 200px; max-height: 100px; border: 1px solid #ddd; padding: 5px;" />');
                     // Use renamed class selector
                    $('.ppr-remove-logo-button').show();
                });
                mediaUploader.open();
            });
             // Use renamed class selector
            $('.ppr-remove-logo-button').click(function(e) {
                 e.preventDefault();
                  // Use renamed ID selector
                 $('#ppr_company_logo_id').val('');
                  // Use renamed class selector
                 $('.ppr-logo-preview').html('');
                 $(this).hide();
            });
        });
    </script>
    <?php
}

/**
 * Callback function for the Invoicing Details section description.
 */
function ppr_invoice_settings_section_callback() {
    echo __( 'Enter details to be included on invoices generated after proposal approval.', 'pretty-proposals' );
}

/**
 * Render the textarea field for 'Payment Terms'.
 */
function ppr_payment_terms_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['payment_terms'] ) ? $options['payment_terms'] : '';
    echo '<textarea name="ppr_settings[payment_terms]" rows="5" cols="50" class="large-text">' . esc_textarea( $value ) . '</textarea>';
    echo '<p class="description">' . __( 'e.g., Payment due upon receipt, Net 15, etc.', 'pretty-proposals' ) . '</p>';
}

/**
 * Render the textarea field for 'Banking Details'.
 */
function ppr_banking_details_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['banking_details'] ) ? $options['banking_details'] : '';
    echo '<textarea name="ppr_settings[banking_details]" rows="5" cols="50" class="large-text">' . esc_textarea( $value ) . '</textarea>';
    echo '<p class="description">' . __( 'Enter your bank account details for payment (Account Name, Number, Bank, etc.), one detail per line.', 'pretty-proposals' ) . '</p>';
}

/**
 * Render the input field for 'Currency Symbol'.
 */
function ppr_currency_symbol_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['currency_symbol'] ) ? $options['currency_symbol'] : '$'; // Default to $
    echo '<input type="text" name="ppr_settings[currency_symbol]" value="' . esc_attr( $value ) . '" size="5" />';
    echo '<p class="description">' . __( 'e.g., $, €, £, R', 'pretty-proposals' ) . '</p>';
}

/**
 * Render the input field for 'Payment Due Days'.
 */
function ppr_invoice_due_days_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['invoice_due_days'] ) ? $options['invoice_due_days'] : 30; // Default to 30 days
    echo '<input type="number" step="1" min="0" name="ppr_settings[invoice_due_days]" value="' . esc_attr( $value ) . '" class="small-text" /> ' . __( 'days', 'pretty-proposals' );
    echo '<p class="description">' . __( 'Number of days until the invoice payment is due (e.g., 0 for due upon receipt, 30 for Net 30). Used to calculate the Due Date on the invoice.', 'pretty-proposals' ) . '</p>';
}

/**
 * Get the default content for the invoice email body.
 */
function ppr_get_default_invoice_email_body() {
    // Use nl2br compatible format
    return "Dear {client_name},

Thank you for accepting the proposal for: {proposal_title}.

Please find attached the invoice ({invoice_number}) for this project.

Payment details can be found within the invoice.

If you have any questions, please let us know.

Thank you,
{your_name}
{your_company_name}";
}

/**
 * Render the textarea field for 'Invoice Email Body Template'.
 */
function ppr_invoice_email_body_render() {
    $options = get_option( 'ppr_settings' );
    $value = isset( $options['invoice_email_body'] ) && !empty( trim( $options['invoice_email_body'] ) ) 
             ? $options['invoice_email_body'] 
             : ppr_get_default_invoice_email_body();
    
    echo '<textarea name="ppr_settings[invoice_email_body]" rows="10" cols="50" class="large-text code">' . esc_textarea( $value ) . '</textarea>';
    
    // Display available placeholders
    echo '<p class="description">' . __( 'Customize the body of the invoice email sent to the client. Available placeholders:', 'pretty-proposals' ) . '</p>';
    echo '<ul style="list-style: disc; margin-left: 20px;">';
    echo '<li><code>{client_name}</code> - ' . __( 'Client\'s Name', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{proposal_title}</code> - ' . __( 'Original Proposal Title', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{invoice_number}</code> - ' . __( 'Generated Invoice Number', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{your_name}</code> - ' . __( 'Your Name (from General Settings)', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{your_company_name}</code> - ' . __( 'Your Company Name (from Settings)', 'pretty-proposals' ) . '</li>';
    echo '<li><code>{site_name}</code> - ' . __( 'Your Site Name', 'pretty-proposals' ) . '</li>';
    // Add more placeholders if needed later (e.g., {invoice_total}, {due_date})
    echo '</ul>';
}

/**
 * Sanitize settings before saving.
 *
 * @param array $input Raw input settings.
 * @return array Sanitized settings.
 */
function ppr_sanitize_settings( $input ) {
    $sanitized_input = array();

    // Sanitize Company Info
     if ( isset( $input['company_name'] ) ) {
        $sanitized_input['company_name'] = sanitize_text_field( $input['company_name'] );
    }
     if ( isset( $input['company_address'] ) ) {
         // Allow line breaks but sanitize other text
        $sanitized_input['company_address'] = implode( "\n", array_map( 'sanitize_text_field', explode( "\n", $input['company_address'] ) ) );
    }
     if ( isset( $input['company_phone'] ) ) {
        $sanitized_input['company_phone'] = sanitize_text_field( $input['company_phone'] ); // Basic sanitization, consider specific phone validation if needed
    }
     if ( isset( $input['company_email'] ) ) {
        $sanitized_input['company_email'] = sanitize_email( $input['company_email'] );
    }

    // Sanitize Email Sender Info
    if ( isset( $input['from_name'] ) ) {
        $sanitized_input['from_name'] = sanitize_text_field( $input['from_name'] );
    }
    if ( isset( $input['from_email'] ) ) {
        $sanitized_input['from_email'] = sanitize_email( $input['from_email'] );
        // Basic check if it looks like a valid email after sanitization
        if ( !empty($input['from_email']) && !is_email( $sanitized_input['from_email'] ) ) {
             // Not a valid email, revert to empty or maybe previous value? Let\'s revert to empty.
             $sanitized_input['from_email'] = '';
              // Use renamed settings group ID
             add_settings_error('ppr_settings', 'invalid_from_email', __('The From Email entered was not valid and was not saved.', 'pretty-proposals'), 'error');
        }
    }
    // Sanitize logo ID
    if ( isset( $input['company_logo_id'] ) ) {
        $sanitized_input['company_logo_id'] = absint( $input['company_logo_id'] ); // Ensure it's a positive integer
    }
     // Sanitize email body (allow basic HTML)
    if ( isset( $input['email_body'] ) ) {
        $sanitized_input['email_body'] = wp_kses_post( $input['email_body'] ); // Allow safe HTML like p, br, strong, em, a
    }

    // Sanitize Invoicing Details
     if ( isset( $input['payment_terms'] ) ) {
        $sanitized_input['payment_terms'] = sanitize_textarea_field( $input['payment_terms'] );
    }
     if ( isset( $input['banking_details'] ) ) {
        // Allow line breaks but sanitize other text
         $sanitized_input['banking_details'] = implode( "\n", array_map( 'sanitize_text_field', explode( "\n", $input['banking_details'] ) ) );
    }

    // Sanitize Currency Symbol
    if ( isset( $input['currency_symbol'] ) ) {
        // Basic sanitization, allow common symbols and some letters
        $sanitized_input['currency_symbol'] = sanitize_text_field( $input['currency_symbol'] );
        // Optionally limit length
        $sanitized_input['currency_symbol'] = mb_substr( $sanitized_input['currency_symbol'], 0, 10 ); 
    }

    // Sanitize Invoice Due Days
    if ( isset( $input['invoice_due_days'] ) ) {
        $sanitized_input['invoice_due_days'] = absint( $input['invoice_due_days'] ); // Ensure positive integer or zero
    }

    // Sanitize Invoice Email Body (allow basic HTML)
    if ( isset( $input['invoice_email_body'] ) ) {
         $allowed_html = [ // Define allowed HTML tags and attributes
            'a' => [ 'href' => [], 'title' => [], 'target' => [] ],
            'br' => [],
            'em' => [],
            'strong' => [],
            'p' => [],
            'ul' => [],
            'ol' => [],
            'li' => [],
        ];
        // Allow placeholders like {placeholder}
        $sanitized_input['invoice_email_body'] = wp_kses( $input['invoice_email_body'], $allowed_html );
        // Basic sanitization for placeholders - remove extra braces etc.
        $sanitized_input['invoice_email_body'] = preg_replace('/[\{\}]{2,}/', '{', $sanitized_input['invoice_email_body']); // Reduce multiple braces
        $sanitized_input['invoice_email_body'] = preg_replace('/\{([^\}]+)\}/', '{$1}', $sanitized_input['invoice_email_body']); // Ensure single braces around valid chars

    }

    return $sanitized_input;
}


/**
 * Render the main Settings page HTML.
 */
function ppr_render_settings_page() {
    // Check user capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap" style="position: relative;"> <?php // Added relative positioning for the button container ?>
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        
        <?php // --- Buy Me a Coffee Button --- ?>
        <a href="https://www.paypal.com/donate/?hosted_button_id=BZQDFPPXPY5BU" 
           target="_blank" 
           rel="noopener noreferrer" 
           style="position: absolute; top: 15px; right: 20px; background: #ffdd00; color: #444; padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.1); font-size: 0.9em; z-index: 10;">
           ☕ Buy Me a Coffee
        </a>
        <?php // ------------------------------ ?>

        <form action="options.php" method="post">
            <?php
            // Output security fields for the registered setting group (Renamed)
            settings_fields( 'ppr_settings_group' );
            // Output setting sections and fields (Using renamed page slug)
            do_settings_sections( 'ppr-settings' );
            // Output save settings button
            submit_button( __( 'Save Settings', 'pretty-proposals' ) );
            ?>
        </form>
    </div>
    <?php
}

// --- Template Loading for Public View ---

/**
 * Load a custom template file for the public proposal view.
 *
 * @param string $template The path of the template to include.
 * @return string Path to the template file.
 */
function ppr_load_proposal_template( $template ) {
    global $wp_query;

    // Check if this is a single pretty_proposal and the proposal_key query var is set.
    // if ( is_singular('pretty_proposal') && isset($wp_query->query_vars['proposal_key']) ) {
    // More robust check: Check query vars directly set by our rewrite rule
    if ( isset($wp_query->query_vars['post_type']) &&
         $wp_query->query_vars['post_type'] === 'pretty_proposal' &&
         isset($wp_query->query_vars['p']) && // Check for post ID query var
         is_numeric($wp_query->query_vars['p']) &&
         isset($wp_query->query_vars['proposal_key']) )
    {

        // Security Check: Verify the key matches the post meta.
        // Use the post ID directly from query vars
        $post_id = intval($wp_query->query_vars['p']); 
        // Ensure the global $post is setup correctly for the template, otherwise template functions might fail
        // Note: This might already be handled by WP query process if 'p' is set, but explicit setup is safer here.
        // query_posts('p=' . $post_id . '&post_type=pretty_proposal'); // Can cause issues, avoid if possible.
        // Better: Setup global post data if needed AFTER validation

        $submitted_key = $wp_query->query_vars['proposal_key'];
        $stored_key = get_post_meta( $post_id, '_ppr_proposal_key', true );

        if ( empty($stored_key) || $submitted_key !== $stored_key ) {
            // Invalid key - show a 404 or an error message template?
            // For now, let's fall back to the theme's 404 template.
            $wp_query->set_404();
            status_header( 404 );
            return get_404_template();
        }

        // Key is valid, load our custom template.
        $plugin_template = plugin_dir_path( __FILE__ ) . 'templates/single-pretty_proposal-public.php';

        // Check if the template exists in the plugin.
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
        // Optional: Allow theme overrides? (e.g., check for theme/template-parts/single-pretty_proposal-public.php)
    }

    return $template; // Fall back to default theme template handling
}
add_filter( 'template_include', 'ppr_load_proposal_template' );

// --- Client Response Handling ---

/**
 * Handle the form submission from the public proposal view.
 */
function ppr_handle_proposal_response_action() {

    // 1. Verify Nonce
    $post_id = isset($_POST['proposal_id']) ? absint($_POST['proposal_id']) : 0;
    $nonce = isset($_POST['ppr_response_nonce']) ? sanitize_key($_POST['ppr_response_nonce']) : '';
    if ( ! $post_id || ! $nonce || ! wp_verify_nonce( $nonce, 'ppr_proposal_response_' . $post_id ) ) {
        wp_die(__( 'Security check failed.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 403 );
    }

    // 2. Verify Proposal Key
    $submitted_key = isset($_POST['proposal_key']) ? sanitize_text_field($_POST['proposal_key']) : '';
    $stored_key = get_post_meta( $post_id, '_ppr_proposal_key', true );
    if ( empty($stored_key) || $submitted_key !== $stored_key ) {
         wp_die(__( 'Invalid proposal key.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 403 );
    }

    // 3. Check if already responded
    $current_status = get_post_meta( $post_id, '_ppr_proposal_status', true );
    if ( in_array($current_status, ['accepted', 'rejected']) ) {
        wp_die(__( 'This proposal has already been responded to.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 400 );
    }

    // 4. Get and Validate Decision
    $decision = isset($_POST['ppr_decision']) ? sanitize_key($_POST['ppr_decision']) : '';
    if ( ! in_array($decision, ['accepted', 'rejected']) ) {
        wp_die(__( 'Invalid decision submitted.', 'pretty-proposals' ), __( 'Error', 'pretty-proposals' ), 400 );
    }

    // 5. Sanitize Comment
    $comment = isset($_POST['ppr_comments']) ? sanitize_textarea_field($_POST['ppr_comments']) : '';

    // --- Process Data ---

    // Update Status
    update_post_meta( $post_id, '_ppr_proposal_status', $decision );

    // Save Comment (as post meta for simplicity)
    if ( ! empty( $comment ) ) {
        update_post_meta( $post_id, '_ppr_client_comment', $comment );
    }

    // --- Notify Admin (Optional) ---
    $admin_email = get_option('admin_email');
    $proposal_title = get_the_title($post_id);
    $client_name = get_post_meta( $post_id, '_ppr_client_name', true );
    $status_label = ucwords($decision);
    $subject = sprintf(__( 'Proposal Response: %s - %s', 'pretty-proposals' ), $proposal_title, $status_label);
    $message = sprintf(__( 'The client %s has %s the proposal "%s".', 'pretty-proposals' ),
        $client_name ? '(' . $client_name . ')' : '', // Add client name if available
        strtolower($status_label), // accepted/rejected
        $proposal_title
    );
    if (!empty($comment)) {
        $message .= "\n\n" . __( 'Client Comment:', 'pretty-proposals' ) . "\n" . $comment;
    }
    $message .= "\n\n" . sprintf(__( 'You can view the proposal here: %s', 'pretty-proposals' ), get_edit_post_link($post_id));

    wp_mail( $admin_email, $subject, $message );

    // --- If Accepted, Send Invoice Email ---
    if ( $decision === 'accepted' ) {
        $invoice_sent = ppr_send_invoice_email( $post_id );
        if ( is_wp_error( $invoice_sent ) ) {
            // Log error, but don't stop the client redirect
            error_log( "Pretty Proposals: Failed to auto-send invoice for accepted proposal {$post_id}. Error: " . $invoice_sent->get_error_message() );
            // Maybe add an admin notice?
        }
    }

    // --- Redirect User ---
    $redirect_url = home_url( '/proposal/' . $post_id . '/' . $stored_key . '/' );
    $redirect_url = add_query_arg( 'response', 'success', $redirect_url ); // Add query arg for success message
    wp_safe_redirect( $redirect_url );
    exit;
}
// Hook for non-logged-in users
add_action( 'admin_post_nopriv_ppr_handle_proposal_response', 'ppr_handle_proposal_response_action' );
// Hook for logged-in users (might not be typical use case, but good practice)
add_action( 'admin_post_ppr_handle_proposal_response', 'ppr_handle_proposal_response_action' );

/**
 * Callback function to display HTML for the Proposal Items meta box.
 *
 * @param WP_Post $post The current post object.
 */
function ppr_proposal_items_meta_box_html( $post ) {
    // Nonce is added in client details box

    $items = get_post_meta( $post->ID, '_ppr_proposal_items', true );
    if ( empty( $items ) ) {
        $items = array( array( 'description' => '', 'price' => '' ) ); // Start with one empty row
    }

    ?>
    <div id="ppr-proposal-items-container">
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php _e('Description', 'pretty-proposals'); ?></th>
                    <th style="width: 20%;"><?php _e('Price', 'pretty-proposals'); ?></th>
                    <th style="width: 10%; text-align: center;"><?php _e('Remove', 'pretty-proposals'); ?></th>
                </tr>
            </thead>
            <tbody id="ppr-line-items-body">
                <?php foreach ( $items as $index => $item ) : ?>
                    <?php
                        $description = isset( $item['description'] ) ? $item['description'] : '';
                        $price = isset( $item['price'] ) ? $item['price'] : '';
                    ?>
                    <tr class="ppr-line-item">
                        <td>
                            <input type="text" name="ppr_items[<?php echo $index; ?>][description]" value="<?php echo esc_attr( $description ); ?>" class="widefat" />
                        </td>
                        <td>
                            <input type="number" step="0.01" min="0" name="ppr_items[<?php echo $index; ?>][price]" value="<?php echo esc_attr( $price ); ?>" class="widefat ppr-item-price" />
                        </td>
                        <td style="text-align: center;">
                            <button type="button" class="button button-link-delete ppr-remove-item">&times;</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">
                         <button type="button" class="button button-secondary" id="ppr-add-item"><?php _e('Add Item', 'pretty-proposals'); ?></button>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>

    <?php // Hidden template row for adding new items ?>
    <script type="text/html" id="ppr-line-item-template">
        <tr class="ppr-line-item">
            <td>
                <input type="text" name="ppr_items[{index}][description]" value="" class="widefat" />
            </td>
            <td>
                <input type="number" step="0.01" min="0" name="ppr_items[{index}][price]" value="" class="widefat ppr-item-price" />
            </td>
            <td style="text-align: center;">
                <button type="button" class="button button-link-delete ppr-remove-item">&times;</button>
            </td>
        </tr>
    </script>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            var itemIndex = <?php echo count( $items ); ?>;

            // Add Item
            $('#ppr-add-item').on('click', function() {
                var template = $('#ppr-line-item-template').html().replace(/\{index\}/g, itemIndex);
                $('#ppr-line-items-body').append(template);
                itemIndex++;
            });

            // Remove Item
            $('#ppr-proposal-items-container').on('click', '.ppr-remove-item', function() {
                // Prevent removing the last row if desired (optional)
                if ($('#ppr-line-items-body .ppr-line-item').length > 1) {
                    $(this).closest('tr.ppr-line-item').remove();
                } else {
                    // Clear the fields of the last row instead of removing it
                    $(this).closest('tr.ppr-line-item').find('input').val('');
                    // alert('Cannot remove the last item.'); // Optional feedback
                }
            });
        });
    </script>
    <?php
}
