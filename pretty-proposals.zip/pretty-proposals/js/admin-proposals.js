jQuery(document).ready(function($) {

    // Handle Send Proposal button click
    // Use renamed ID selector
    $(document).on('click', '#ppr-send-proposal-button', function(e) {
        e.preventDefault();

        var $button = $(this);
        var $spinner = $button.siblings('.spinner');
        // Use renamed ID selector
        var $statusDiv = $('#ppr-send-status');
        // Use renamed ID selector
        var $statusSelect = $('#ppr_proposal_status'); // The status dropdown
        var postId = $button.data('postid');
        // Use renamed ID selector
        var nonce = $('#ppr_send_proposal_nonce').val(); // Get nonce from the hidden field in the meta box

        // Use renamed JS object
        // Basic validation
        if (!postId) {
            $statusDiv.html('<p style="color: red;">' + ppr_ajax.error_prefix + ' Missing Post ID.</p>');
            return;
        }
        if (!nonce) {
            $statusDiv.html('<p style="color: red;">' + ppr_ajax.error_prefix + ' Missing security nonce.</p>');
            return;
        }

        // Disable button and show spinner
        $button.prop('disabled', true);
        $spinner.addClass('is-active');
         // Use renamed JS object
        $statusDiv.html('<p>' + ppr_ajax.sending_text + '</p>');

        // AJAX request
        // Use renamed JS object for URL
        $.ajax({
            url: ppr_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'ppr_send_proposal', // Matches the PHP AJAX hook wp_ajax_ppr_send_proposal (Renamed)
                post_id: postId,
                nonce: nonce            // Send the nonce from the meta box field
            },
            success: function(response) {
                if (response.success) {
                    // Use renamed JS object for message
                    $statusDiv.html('<p style="color: green;">' + response.data.message + '</p>');
                    // Update the status dropdown to 'Sent'
                    if ($statusSelect.length) {
                        $statusSelect.val('sent');
                    }
                    // Optionally hide the button after success or leave it enabled for resending
                    // $button.hide();
                    $button.prop('disabled', false); // Re-enable for potential resend

                } else {
                    // Display error message from server
                    var errorMessage = response.data || 'Unknown error occurred.';
                     // Use renamed JS object for prefix
                    $statusDiv.html('<p style="color: red;">' + ppr_ajax.error_prefix + ' ' + errorMessage + '</p>');
                    $button.prop('disabled', false); // Re-enable button on error
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                // Handle AJAX communication errors
                 // Use renamed JS object for prefix
                $statusDiv.html('<p style="color: red;">' + ppr_ajax.error_prefix + ' AJAX request failed: ' + textStatus + ' - ' + errorThrown + '</p>');
                $button.prop('disabled', false); // Re-enable button on error
            },
            complete: function() {
                // Hide spinner regardless of success or error
                $spinner.removeClass('is-active');
            }
        });
    });

}); 