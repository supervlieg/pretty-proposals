=== Pretty Proposals ===
Contributors: Willem Prinsloo
Tags: proposals, client management, pdf, email, admin, crm
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage client proposals directly within WordPress using Pretty Proposals. Create, customize, PDF, and send proposals with ease.

== Description ==

Pretty Proposals allows designers, developers, and freelancers to streamline their proposal workflow directly within their WordPress dashboard.

**Features:**

*   Create and manage proposals using a dedicated Custom Post Type (`pretty_proposal`).
*   Fields for Client Name, Company, Email, Scope of Work, and Project Price.
*   Track proposal status (Draft, Sent, Accepted, Rejected).
*   Automatically generate a professional-looking PDF of the proposal (with optional company logo).
*   Add page numbers automatically to the PDF footer.
*   Send the proposal PDF directly to the client via email from the admin screen.
*   Customize the "From" name, email address, and email body text used for sending.
*   View key proposal details (Client, Price, Status) directly in the admin list view.

== Installation ==

1.  Upload the `pretty-proposals` folder to the `/wp-content/plugins/` directory.
2.  **Important:** Download the FPDF library (get the zip file from [fpdf.org](http://www.fpdf.org/)) and place the extracted `fpdf.php` file and the `font` directory inside the `pretty-proposals/lib/` directory within your plugin folder. Create the `lib` directory if it doesn't exist.
3.  Activate the plugin through the 'Plugins' menu in WordPress.
4.  Navigate to the 'Proposals' menu in your WordPress admin sidebar to start creating proposals.
5.  Optionally, configure the sender email address, email body, and company logo under 'Proposals' -> 'Settings'.

== Frequently Asked Questions ==

= Does this require external libraries? =

Yes, it requires the FPDF PHP library for PDF generation. You need to download it separately from fpdf.org and place `fpdf.php` and the `font` directory into the `pretty-proposals/lib/` folder.

= Can I customize the PDF template? =

Currently, PDF customization requires modifying the PHP code within the `ppr_generate_proposal_pdf` function in `pretty-proposals.php`. Adding the company logo is supported via the Settings page.

= Can I customize the email template? =

Yes. The "From" name/address and the main email body content can be customized under 'Proposals' -> 'Settings'. Use placeholders like `{client_name}`, `{proposal_title}`, and `{site_name}` in the body template.

== Screenshots ==

1.  Proposal Edit Screen with Meta Boxes
2.  Proposal List View with Custom Columns
3.  Send Proposal Meta Box
4.  Settings Page (Email, PDF Logo, Email Body)

(Note: Add actual screenshot file references here if submitting to WordPress.org, e.g., `/assets/screenshot-1.png`)

== Changelog ==

= 1.0.1 =
* Renamed plugin to "Pretty Proposals" (folder, file, functions, IDs, slugs, options, meta keys, text domain) to avoid potential conflicts.
* Fixed fatal PHP Parse Error on activation related to `SetFont` syntax in PDF footer.
* Added page number support to PDF footer.
* Added customizable email body template setting with placeholders.
* Added company logo upload and inclusion in PDF.
* Updated Readme files.

= 1.0.0 =
* Initial release (as WP Proposals).
* Features: CPT, Meta Fields, PDF Generation (FPDF), Email Sending, Admin Columns, Settings Page (From Name/Email).

== Upgrade Notice ==

= 1.0.1 =
This version renames the plugin to Pretty Proposals and changes internal identifiers, including custom field (meta) keys. Proposals created with version 1.0.0 will NOT retain their specific data (Client Name, Price, Status, etc.) after upgrading. Backup your site before upgrading if needed, although re-entering data for existing proposals may be required.

= 1.0.0 =
Initial release. 