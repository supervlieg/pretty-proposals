<?php
/**
 * Public Template for Single Pretty Proposal
 *
 * This template is loaded via the template_include filter in the main plugin file
 * when a proposal is accessed via the unique shareable link.
 *
 * It bypasses the theme's single post template.
 */

// Basic Security: Ensure we are in the WordPress environment.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get proposal data
global $post;
$post_id = $post->ID;

// --- Fetch Data ---
$proposal_title = $post->post_title;
$scope_of_work  = apply_filters('the_content', $post->post_content);

$client_name    = get_post_meta( $post_id, '_ppr_client_name', true );
$client_company = get_post_meta( $post_id, '_ppr_client_company', true );
// $client_email   = get_post_meta( $post_id, '_ppr_client_email', true ); // Likely not needed for public view
$project_price  = get_post_meta( $post_id, '_ppr_project_price', true );
$proposal_number = get_post_meta( $post_id, '_ppr_proposal_number', true );
$current_status = get_post_meta( $post_id, '_ppr_proposal_status', true ) ?: 'draft';
$proposal_date = date( get_option('date_format', 'F j, Y'), strtotime($post->post_date) );
$proposal_key = get_post_meta( $post_id, '_ppr_proposal_key', true ); // Needed for form submission

// Fetch Company details from settings
$options = get_option( 'ppr_settings' );
$company_name = isset($options['company_name']) ? $options['company_name'] : '';
$company_address = isset($options['company_address']) ? nl2br(esc_html($options['company_address'])) : '';
$company_phone = isset($options['company_phone']) ? $options['company_phone'] : '';
$company_email = isset($options['company_email']) ? $options['company_email'] : '';
$logo_id = isset( $options['company_logo_id'] ) ? absint( $options['company_logo_id'] ) : 0;
$logo_url = $logo_id ? wp_get_attachment_url( $logo_id ) : '';
$raw_currency_symbol = isset( $options['currency_symbol'] ) ? $options['currency_symbol'] : '$'; // Fetch raw symbol
$currency_symbol = esc_html( html_entity_decode( $raw_currency_symbol, ENT_QUOTES, 'UTF-8' ) ); // Decode then escape

// Has the client already responded?
$already_responded = in_array($current_status, ['accepted', 'rejected']);
$response_message = '';
if ( isset($_GET['response']) && $_GET['response'] === 'success') {
    $response_message = __('Thank you, your response has been recorded.', 'pretty-proposals');
}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html( $proposal_title ); ?> - <?php bloginfo( 'name' ); ?></title>
    <?php // wp_head(); // We generally avoid wp_head() in standalone templates to prevent theme/plugin conflicts ?>
    <style type="text/css">
        /* --- Global --- */
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f7f6; /* Lighter grey background */
            margin: 0;
            padding: 20px 0;
        }
        .proposal-container { 
            max-width: 850px; /* Slightly wider */
            margin: 30px auto; 
            background-color: #ffffff; 
            padding: 40px 50px; /* More padding */
            border: 1px solid #e0e0e0; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.08);
            border-radius: 5px; /* Subtle rounding */
        }
        h1, h2, h3 { color: #1a1a1a; margin-top: 1.5em; margin-bottom: 0.8em; font-weight: 600; }
        h1.proposal-title { font-size: 2.2em; text-align: center; margin-top: 0.5em; margin-bottom: 1.2em; color: #2c3e50; } 
        h2 { font-size: 1.6em; border-bottom: 2px solid #e0e0e0; padding-bottom: 8px; } /* Section titles */
        h3 { font-size: 1.25em; margin-bottom: 0.6em; color: #34495e; } /* Sub-section titles */
        p { margin-bottom: 1em; }
        a { color: #3498db; text-decoration: none; }
        a:hover { text-decoration: underline; }

        /* --- Header --- */
        .proposal-header { 
            margin-bottom: 40px; 
            padding-bottom: 20px; 
            border-bottom: 1px solid #e0e0e0; 
            display: flex; /* Use flexbox for alignment */
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap; /* Allow wrapping on smaller screens */
        }
        /* NEW: Wrapper for logo */
        .header-logo {
            flex-shrink: 0; /* Prevent logo shrinking */
            margin-bottom: 20px; /* Consistent margin */
        }
        .company-logo { max-width: 200px; max-height: 80px; display: block; }

        /* NEW: Wrapper for text details */
        .header-details-wrapper {
            flex-grow: 1;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-left: 30px; /* Space between logo and text */
            flex-wrap: wrap; /* Allow wrapping inside if needed */
        }

        .company-details { 
            width: 55%; /* Relative to wrapper */
            font-size: 0.9em; 
            color: #555; 
            line-height: 1.5; 
            margin-bottom: 15px; /* Spacing when wrapped */
        }
        .proposal-meta { 
            width: 40%; /* Relative to wrapper */
            text-align: right; 
            font-size: 0.9em; 
            color: #555; 
            line-height: 1.5; 
            margin-bottom: 15px; /* Spacing when wrapped */
        }
        .company-details p, .proposal-meta p { margin: 0 0 6px 0; }
        .company-details strong, .proposal-meta strong { color: #1a1a1a; }
        
        /* --- Sections --- */
        .proposal-section { margin-bottom: 35px; }
        .client-info { 
            background-color: #f9f9f9; /* Slightly different background */
            padding: 20px 25px;
            margin-bottom: 35px; 
            border: 1px solid #e7e7e7;
            border-radius: 4px; 
        }
        .client-info h3 { margin-top: 0; }
        .scope-of-work { margin-bottom: 35px; }
        .scope-of-work p:last-child { margin-bottom: 0; }

        /* --- Pricing / Line Items Table --- */
        .proposal-pricing h2 { margin-bottom: 20px; } /* More space after heading */
        .proposal-items-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 15px; 
            font-size: 0.95em;
        }
        .proposal-items-table th, .proposal-items-table td { 
            border: 1px solid #e0e0e0; 
            padding: 12px 15px; /* More padding */
            text-align: left; 
            vertical-align: top; /* Align top for multi-line descriptions */
        }
        .proposal-items-table thead th { 
            background-color: #f5f5f5; /* Light grey header */
            font-weight: 600; 
            color: #333;
            border-bottom-width: 2px; /* Thicker bottom border */
        }
        .proposal-items-table .price-col { 
            text-align: right; 
            width: 120px; /* Fixed width for price column */
        }
        .proposal-items-table tbody tr:nth-child(even) { 
            background-color: #fdfdfd; /* Subtle striping */
        }
        .proposal-items-table tfoot td { 
            border-top: 2px solid #e0e0e0; /* Thicker top border */
            font-weight: bold; 
            background-color: #f9f9f9;
        }
        .proposal-items-table .total-label { text-align: right; }
        .proposal-items-table .total-price { text-align: right; }

        /* --- Response Form & Messages --- */
        .response-form { 
            margin-top: 40px; 
            padding: 30px; /* More padding */
            border-top: 1px solid #e0e0e0; 
            background-color: #f9f9f9;
            border-radius: 4px;
        }
        .response-form h3 { margin-top: 0; }
        .response-form label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 0.9em; }
        .response-form textarea { 
            width: 100%; 
            min-height: 100px; /* Taller */
            margin-bottom: 20px; 
            padding: 12px;
            border: 1px solid #ccc; 
            border-radius: 4px; 
            box-sizing: border-box; 
            font-size: 1em;
        }
        .response-form .buttons { margin-top: 10px; }
        .response-form .buttons button { 
            padding: 12px 25px; 
            font-size: 1.05em; 
            font-weight: bold;
            cursor: pointer; 
            border: none; 
            border-radius: 4px; 
            margin-right: 10px; 
            transition: background-color 0.2s ease;
        }
        .response-form .buttons .approve-button { background-color: #2ecc71; color: white; } /* Brighter green */
        .response-form .buttons .reject-button { background-color: #e74c3c; color: white; } /* Brighter red */
        .response-form .buttons .approve-button:hover { background-color: #27ae60; }
        .response-form .buttons .reject-button:hover { background-color: #c0392b; }
        
        .response-message { 
            padding: 15px 20px;
            margin-bottom: 30px; 
            border-radius: 4px; 
            font-size: 1.05em;
            border: 1px solid transparent;
        }
        .response-message.success { background-color: #dff0d8; border-color: #d6e9c6; color: #3c763d; }
        .response-message.responded { background-color: #f5f5f5; border-color: #e3e3e3; color: #333; }
        .response-message hr { border: 0; border-top: 1px solid #ccc; margin: 15px 0; }

        /* --- Footer --- */
        .proposal-footer { 
            margin-top: 40px; 
            padding-top: 20px; 
            border-top: 1px solid #e0e0e0; 
            text-align: center; 
            font-size: 0.9em; 
            color: #777; 
        }

        /* --- Responsive --- */
        @media (max-width: 768px) {
            .proposal-container { padding: 30px; }
            .proposal-header { flex-direction: column; align-items: center; } /* Stack logo and text wrapper */
            .header-logo { margin-bottom: 25px; } /* More space below logo */
            .header-details-wrapper { 
                 flex-direction: column; 
                 align-items: stretch; /* Stretch children full width */
                 width: 100%; 
                 margin-left: 0; /* Remove side margin */
                 margin-top: 0; 
             } 
            .company-details, .proposal-meta { width: 100%; text-align: left; margin-bottom: 15px; }
            .proposal-meta { margin-bottom: 0; } /* No margin on last item */
            h1.proposal-title { font-size: 1.8em; }
            h2 { font-size: 1.4em; }
            h3 { font-size: 1.15em; }
        }
        @media (max-width: 480px) {
            body { padding: 10px 0; }
            .proposal-container { padding: 20px 15px; margin: 15px auto; }
            .response-form .buttons button { width: 100%; margin-bottom: 10px; margin-right: 0; }
            .response-form .buttons .reject-button { margin-bottom: 0; }
            .proposal-items-table th, .proposal-items-table td { padding: 8px 10px; }
            .proposal-items-table .price-col { width: 90px; }
        }
    </style>
</head>
<body>
    <div class="proposal-container">

        <?php if ($response_message): ?>
            <div class="response-message success"><?php echo esc_html($response_message); ?></div>
        <?php endif; ?>

        <div class="proposal-header">
            <?php if ($logo_url): ?>
                <div class="header-logo"> <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($company_name ?: bloginfo('name')); ?>" class="company-logo" /></div>
            <?php endif; ?>

            <div class="header-details-wrapper">
                <div class="company-details">
                     <?php if ($company_name): ?><p><strong><?php echo esc_html($company_name); ?></strong></p><?php endif; ?>
                     <?php if ($company_address): ?><p><?php echo $company_address; // Already escaped and nl2br'd ?></p><?php endif; ?>
                     <?php if ($company_phone): ?><p><?php _e('Phone:', 'pretty-proposals'); ?> <?php echo esc_html($company_phone); ?></p><?php endif; ?>
                     <?php if ($company_email): ?><p><?php _e('Email:', 'pretty-proposals'); ?> <?php echo esc_html($company_email); ?></p><?php endif; ?>
                </div>

                <div class="proposal-meta">
                    <p><strong><?php _e('PROPOSAL', 'pretty-proposals'); ?></strong></p>
                    <?php if ($proposal_number): ?><p><?php _e('Proposal #:', 'pretty-proposals'); ?> <?php echo esc_html($proposal_number); ?></p><?php endif; ?>
                    <p><?php _e('Date:', 'pretty-proposals'); ?> <?php echo esc_html($proposal_date); ?></p>
                    <p><?php _e('Status:', 'pretty-proposals'); ?> <strong><?php echo esc_html(ucwords($current_status)); ?></strong></p>
                </div>
            </div> <?php // end header-details-wrapper ?>
        </div>

        <h1 class="proposal-title">Proposal: <?php echo esc_html($proposal_title); ?></h1>

        <div class="client-info section">
            <h3><?php _e('Prepared For:', 'pretty-proposals'); ?></h3>
            <?php if ($client_name): ?><p><strong><?php echo esc_html($client_name); ?></strong></p><?php endif; ?>
            <?php if ($client_company): ?><p><?php echo esc_html($client_company); ?></p><?php endif; ?>
        </div>

        <div class="scope-of-work section">
            <h3><?php _e('Scope of Work', 'pretty-proposals'); ?></h3>
            <?php echo $scope_of_work; // Content with HTML formatting ?>
        </div>

        <div class="proposal-section proposal-pricing">
            <h2><?php _e( 'Project Breakdown & Price', 'pretty-proposals' ); ?></h2>
            <?php
            $line_items = get_post_meta( $post_id, '_ppr_proposal_items', true );
            if ( ! empty( $line_items ) && is_array( $line_items ) ) :
                $total_price = 0;
            ?>
                <table class="proposal-items-table">
                    <thead>
                        <tr>
                            <th><?php _e( 'Description', 'pretty-proposals' ); ?></th>
                            <th class="price-col"><?php _e( 'Price', 'pretty-proposals' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $line_items as $item ) :
                            $item_description = isset($item['description']) ? $item['description'] : '';
                            $item_price = isset($item['price']) ? floatval($item['price']) : 0;
                            $total_price += $item_price;
                        ?>
                            <tr>
                                <td><?php echo nl2br( esc_html( $item_description ) ); ?></td>
                                <td class="price-col"><?php echo $currency_symbol . esc_html( number_format_i18n( $item_price, 2 ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td class="total-label"><?php _e( 'Total', 'pretty-proposals' ); ?></td>
                            <td class="price-col total-price"><?php echo $currency_symbol . esc_html( number_format_i18n( $total_price, 2 ) ); ?></td>
                        </tr>
                    </tfoot>
                </table>
            <?php else : ?>
                <p><?php _e( 'Detailed pricing information will be provided.', 'pretty-proposals' ); ?></p>
            <?php endif; ?>
        </div>

        <?php // --- Response Form --- ?>
        <?php if ( ! $already_responded ): ?>
            <div class="response-form">
                <h3><?php _e('Your Response', 'pretty-proposals'); ?></h3>
                <form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
                    <input type="hidden" name="action" value="ppr_handle_proposal_response"> <?php // Hook for admin-post.php ?>
                    <input type="hidden" name="proposal_id" value="<?php echo esc_attr($post_id); ?>">
                    <input type="hidden" name="proposal_key" value="<?php echo esc_attr($proposal_key); ?>">
                    <?php wp_nonce_field( 'ppr_proposal_response_' . $post_id, 'ppr_response_nonce' ); ?>

                    <p><?php _e('Please review the proposal above and indicate your decision below.', 'pretty-proposals'); ?></p>

                    <div>
                        <label for="ppr_comments"><?php _e('Comments (Optional):', 'pretty-proposals'); ?></label>
                        <textarea id="ppr_comments" name="ppr_comments"></textarea>
                    </div>

                    <div class="buttons">
                        <button type="submit" name="ppr_decision" value="accepted" class="approve-button"><?php _e('Accept Proposal', 'pretty-proposals'); ?></button>
                        <button type="submit" name="ppr_decision" value="rejected" class="reject-button"><?php _e('Reject Proposal', 'pretty-proposals'); ?></button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="response-message responded">
                <?php echo sprintf(
                    /* Translators: %s is the status (Accepted/Rejected) */
                    esc_html__( 'This proposal was marked as %s.', 'pretty-proposals' ),
                    '<strong>' . esc_html(ucwords($current_status)) . '</strong>'
                 ); ?>
                 <?php
                 // Optionally display saved comment here if implemented
                 $client_comment = get_post_meta( $post_id, '_ppr_client_comment', true );
                 if ( $client_comment ) {
                     echo '<hr style="margin: 10px 0; border-top: 1px solid #ccc;">' . '<p><strong>' . esc_html__( 'Your comment:', 'pretty-proposals' ) . '</strong><br>' . nl2br(esc_html($client_comment)) . '</p>';
                 }
                 ?>
            </div>
        <?php endif; ?>

        <div class="proposal-footer">
            <p><?php _e('Thank you for considering this proposal.', 'pretty-proposals'); ?></p>
        </div>

    </div> <?php // .proposal-container ?>
    <?php // wp_footer(); // Avoid wp_footer in standalone templates ?>
</body>
</html> 